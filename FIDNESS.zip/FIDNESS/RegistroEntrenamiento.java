import java.util.*;

// Registro de un entrenamiento realizado
public class RegistroEntrenamiento {
    private Date fecha;
    private String nombreRutina;
    private List<EjercicioRealizado> ejerciciosRealizados;

    public RegistroEntrenamiento(Date fecha, String nombreRutina) {
        this.fecha = fecha;
        this.nombreRutina = nombreRutina;
        this.ejerciciosRealizados = new ArrayList<>();
    }
    public Date getFecha() { return fecha; }
    public String getNombreRutina() { return nombreRutina; }
    public List<EjercicioRealizado> getEjerciciosRealizados() { return ejerciciosRealizados; }
    public void agregarEjercicioRealizado(EjercicioRealizado ejercicio) { ejerciciosRealizados.add(ejercicio); }
    public String toString() {
        return nombreRutina + " - " + fecha;
    }
}
