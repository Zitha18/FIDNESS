// Interfaz para recuperación de contraseña
public class InterfazRecuperarPassword {
    public void mostrarFormularioRecuperacion() {
        System.out.println("Ingrese su correo para recibir el enlace de recuperación:");
        // Aquí iría la lógica para pedir el correo
    }
    public void mostrarMensajeEnviado() {
        System.out.println("Correo de recuperación enviado. Revise su bandeja de entrada.");
    }
}
