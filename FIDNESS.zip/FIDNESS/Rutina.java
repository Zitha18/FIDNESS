import java.util.*;

// Modelo de rutina personalizada
public class Rutina {
    private String nombre;
    private List<EjercicioEnRutina> ejercicios;

    public Rutina(String nombre) {
        this.nombre = nombre;
        this.ejercicios = new ArrayList<>();
    }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public List<EjercicioEnRutina> getEjercicios() { return ejercicios; }
    public void agregarEjercicio(Ejercicio ejercicio, String nota) {
        ejercicios.add(new EjercicioEnRutina(ejercicio, nota));
    }
    public void eliminarEjercicio(int index) {
        if (index >= 0 && index < ejercicios.size()) ejercicios.remove(index);
    }
    public void moverEjercicio(int from, int to) {
        if (from >= 0 && from < ejercicios.size() && to >= 0 && to < ejercicios.size()) {
            EjercicioEnRutina temp = ejercicios.remove(from);
            ejercicios.add(to, temp);
        }
    }
    public void setNotaEjercicio(int index, String nota) {
        if (index >= 0 && index < ejercicios.size()) ejercicios.get(index).setNota(nota);
    }
    public Rutina duplicar() {
        Rutina copia = new Rutina(nombre + " (Copia)");
        for (EjercicioEnRutina er : ejercicios) {
            copia.ejercicios.add(new EjercicioEnRutina(er.getEjercicio(), er.getNota()));
        }
        return copia;
    }
    public String toString() {
        return nombre + " - " + ejercicios.size() + " ejercicios";
    }
}
