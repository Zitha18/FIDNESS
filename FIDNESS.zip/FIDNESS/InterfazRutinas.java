import javax.swing.*;
import java.awt.*;
import java.util.*;

// GUI para rutinas
public class InterfazRutinas extends JFrame {
    private RutinaManager rutinaManager;
    private EjercicioManager ejercicioManager;

    public InterfazRutinas(RutinaManager rutinaManager, EjercicioManager ejercicioManager) {
        this.rutinaManager = rutinaManager;
        this.ejercicioManager = ejercicioManager;
        setTitle("Mis Rutinas");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        DefaultListModel<Rutina> modeloLista = new DefaultListModel<>();
        JList<Rutina> listaRutinas = new JList<>(modeloLista);
        listaRutinas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(listaRutinas);
        add(scroll, BorderLayout.CENTER);

        JButton btnNueva = new JButton("+");
        JButton btnEditar = new JButton("Editar");
        JButton btnDuplicar = new JButton("Duplicar");
        JButton btnExportar = new JButton("Exportar PDF");
        JPanel panelBotones = new JPanel();
        panelBotones.add(btnNueva);
        panelBotones.add(btnEditar);
        panelBotones.add(btnDuplicar);
        panelBotones.add(btnExportar);
        add(panelBotones, BorderLayout.SOUTH);

        Runnable actualizarLista = () -> {
            modeloLista.clear();
            for (Rutina r : rutinaManager.getListaRutinas()) modeloLista.addElement(r);
        };
        actualizarLista.run();

        btnNueva.addActionListener(e -> {
            String nombre = JOptionPane.showInputDialog(this, "Nombre de la rutina:");
            if (nombre != null && !nombre.trim().isEmpty()) {
                rutinaManager.crearRutina(nombre.trim());
                actualizarLista.run();
            }
        });
        btnEditar.addActionListener(e -> {
            Rutina seleccionada = listaRutinas.getSelectedValue();
            if (seleccionada != null) {
                new EditarRutinaPanel(this, seleccionada, ejercicioManager, rutinaManager, actualizarLista).setVisible(true);
            }
        });
        btnDuplicar.addActionListener(e -> {
            Rutina seleccionada = listaRutinas.getSelectedValue();
            if (seleccionada != null) {
                rutinaManager.duplicarRutina(seleccionada);
                actualizarLista.run();
            }
        });
        btnExportar.addActionListener(e -> {
            Rutina seleccionada = listaRutinas.getSelectedValue();
            if (seleccionada != null) {
                JFileChooser chooser = new JFileChooser();
                chooser.setSelectedFile(new java.io.File(seleccionada.getNombre() + ".txt"));
                int res = chooser.showSaveDialog(this);
                if (res == JFileChooser.APPROVE_OPTION) {
                    boolean ok = ExportarPDFUtil.exportarRutina(seleccionada, chooser.getSelectedFile().getAbsolutePath());
                    JOptionPane.showMessageDialog(this, ok ? "Exportado correctamente" : "Error al exportar");
                }
            }
        });
    }
}
