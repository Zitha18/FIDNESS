package cliente;
// Clase base para el cliente
import java.net.*;
import java.io.*;
import modelo.Ejercicio;
import red.Request;
import red.Response;

public class ClienteSocket {
    public static void main(String[] args) {
        String host = "localhost";
        int puerto = 5000;
        try (Socket socket = new Socket(host, puerto);
             ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream in = new ObjectInputStream(socket.getInputStream())) {
            // Ejemplo de login
            Object[] loginData = {"admin@fidness.com", "admin123"};
            Request reqLogin = new Request("loginUsuario", loginData);
            out.writeObject(reqLogin);
            Response respLogin = (Response) in.readObject();
            System.out.println("Login: " + respLogin.mensaje);
            if (respLogin.exito) {
                modelo.Usuario usuarioLog = (modelo.Usuario) respLogin.datos;
                System.out.println("Usuario autenticado: " + usuarioLog.getNombre());
            }
            // Ejemplo: agregar un ejercicio
            Ejercicio nuevo = new Ejercicio(1, "Sentadillas", "Piernas", true);
            Request reqAdd = new Request("agregarEjercicio", nuevo);
            out.writeObject(reqAdd);
            Response respAdd = (Response) in.readObject();
            System.out.println("Agregar: " + respAdd.mensaje);

            // Ejemplo: obtener por id
            Request reqGet = new Request("obtenerEjercicio", 1);
            out.writeObject(reqGet);
            Response respGet = (Response) in.readObject();
            System.out.println("Obtener: " + respGet.mensaje + " - " + respGet.datos);

            // Ejemplo: actualizar
            Ejercicio actualizado = new Ejercicio(1, "Sentadillas profundas", "Piernas", true);
            Request reqUpd = new Request("actualizarEjercicio", actualizado);
            out.writeObject(reqUpd);
            Response respUpd = (Response) in.readObject();
            System.out.println("Actualizar: " + respUpd.mensaje);

            // Ejemplo: obtener todos
            Request reqAll = new Request("obtenerTodosEjercicios", null);
            out.writeObject(reqAll);
            Response respAll = (Response) in.readObject();
            System.out.println("Todos: " + respAll.datos);

            // Ejemplo: eliminar
            Request reqDel = new Request("eliminarEjercicio", 1);
            out.writeObject(reqDel);
            Response respDel = (Response) in.readObject();
            System.out.println("Eliminar: " + respDel.mensaje);

            // Ejemplo CRUD Pregunta
            modelo.Pregunta pregunta = new modelo.Pregunta(1, "¿Cuál es el horario?", "De 8 a 22");
            Request reqPregAdd = new Request("agregarPregunta", pregunta);
            out.writeObject(reqPregAdd);
            Response respPregAdd = (Response) in.readObject();
            System.out.println("Agregar Pregunta: " + respPregAdd.mensaje);

            Request reqPregGet = new Request("obtenerPregunta", 1);
            out.writeObject(reqPregGet);
            Response respPregGet = (Response) in.readObject();
            System.out.println("Obtener Pregunta: " + respPregGet.mensaje + " - " + respPregGet.datos);

            pregunta.setPregunta("¿Cuál es el horario de verano?");
            Request reqPregUpd = new Request("actualizarPregunta", pregunta);
            out.writeObject(reqPregUpd);
            Response respPregUpd = (Response) in.readObject();
            System.out.println("Actualizar Pregunta: " + respPregUpd.mensaje);

            Request reqPregAll = new Request("obtenerTodasPreguntas", null);
            out.writeObject(reqPregAll);
            Response respPregAll = (Response) in.readObject();
            System.out.println("Todas Preguntas: " + respPregAll.datos);

            Request reqPregDel = new Request("eliminarPregunta", 1);
            out.writeObject(reqPregDel);
            Response respPregDel = (Response) in.readObject();
            System.out.println("Eliminar Pregunta: " + respPregDel.mensaje);

            // Ejemplo CRUD InformacionGimnasio
            modelo.InformacionGimnasio info = new modelo.InformacionGimnasio(1, "Fidness Gym", "Av. Siempre Viva 123", "123456789", "8-22");
            Request reqInfoAdd = new Request("agregarInformacion", info);
            out.writeObject(reqInfoAdd);
            Response respInfoAdd = (Response) in.readObject();
            System.out.println("Agregar Info: " + respInfoAdd.mensaje);

            Request reqInfoGet = new Request("obtenerInformacion", 1);
            out.writeObject(reqInfoGet);
            Response respInfoGet = (Response) in.readObject();
            System.out.println("Obtener Info: " + respInfoGet.mensaje + " - " + respInfoGet.datos);

            info.setDireccion("Av. Siempre Viva 456");
            Request reqInfoUpd = new Request("actualizarInformacion", info);
            out.writeObject(reqInfoUpd);
            Response respInfoUpd = (Response) in.readObject();
            System.out.println("Actualizar Info: " + respInfoUpd.mensaje);

            Request reqInfoAll = new Request("obtenerTodaInformacion", null);
            out.writeObject(reqInfoAll);
            Response respInfoAll = (Response) in.readObject();
            System.out.println("Toda Info: " + respInfoAll.datos);

            Request reqInfoDel = new Request("eliminarInformacion", 1);
            out.writeObject(reqInfoDel);
            Response respInfoDel = (Response) in.readObject();
            System.out.println("Eliminar Info: " + respInfoDel.mensaje);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
