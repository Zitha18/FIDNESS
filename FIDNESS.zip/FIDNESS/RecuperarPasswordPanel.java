import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Panel para recuperación de contraseña
public class RecuperarPasswordPanel extends JDialog {
    private UsuarioManager usuarioManager;

    public RecuperarPasswordPanel(JFrame parent, UsuarioManager usuarioManager) {
        super(parent, "Recuperar Contraseña", true);
        this.usuarioManager = usuarioManager;
        setSize(300, 150);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(2, 2));

        JLabel lblCorreo = new JLabel("Correo:");
        JTextField txtCorreo = new JTextField();
        JButton btnEnviar = new JButton("Enviar");
        JButton btnCancelar = new JButton("Cancelar");

        add(lblCorreo); add(txtCorreo);
        add(btnEnviar); add(btnCancelar);

        btnEnviar.addActionListener(e -> {
            String correo = txtCorreo.getText();
            if (usuarioManager.enviarRecuperacion(correo)) {
                JOptionPane.showMessageDialog(this, "Correo de recuperación enviado a: " + correo);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Correo no encontrado");
            }
        });
        btnCancelar.addActionListener(e -> dispose());
    }
}
