import javax.swing.*;
import java.awt.*;
import java.util.List;

// Panel de administración para gestionar categorías
public class PanelAdminCategorias extends JPanel {
    public PanelAdminCategorias(EjercicioManager ejercicioManager) {
        setLayout(new GridLayout(1,2));
        JPanel panelGrupos = new JPanel(new BorderLayout());
        JPanel panelEquip = new JPanel(new BorderLayout());
        panelGrupos.add(new JLabel("Grupos Musculares"), BorderLayout.NORTH);
        panelEquip.add(new JLabel("Equipamiento"), BorderLayout.NORTH);
        DefaultListModel<String> modeloGrupos = new DefaultListModel<>();
        DefaultListModel<String> modeloEquip = new DefaultListModel<>();
        for (String cat : ejercicioManager.getCategoriasGrupos()) modeloGrupos.addElement(cat);
        for (String cat : ejercicioManager.getCategoriasEquipamiento()) modeloEquip.addElement(cat);
        JList<String> listaGrupos = new JList<>(modeloGrupos);
        JList<String> listaEquip = new JList<>(modeloEquip);
        panelGrupos.add(new JScrollPane(listaGrupos), BorderLayout.CENTER);
        panelEquip.add(new JScrollPane(listaEquip), BorderLayout.CENTER);
        JPanel panelBotonesGrupos = new JPanel();
        JButton btnAgregarGrupo = new JButton("Agregar");
        JButton btnRenombrarGrupo = new JButton("Renombrar");
        JButton btnEliminarGrupo = new JButton("Eliminar");
        panelBotonesGrupos.add(btnAgregarGrupo);
        panelBotonesGrupos.add(btnRenombrarGrupo);
        panelBotonesGrupos.add(btnEliminarGrupo);
        panelGrupos.add(panelBotonesGrupos, BorderLayout.SOUTH);
        JPanel panelBotonesEquip = new JPanel();
        JButton btnAgregarEquip = new JButton("Agregar");
        JButton btnRenombrarEquip = new JButton("Renombrar");
        JButton btnEliminarEquip = new JButton("Eliminar");
        panelBotonesEquip.add(btnAgregarEquip);
        panelBotonesEquip.add(btnRenombrarEquip);
        panelBotonesEquip.add(btnEliminarEquip);
        panelEquip.add(panelBotonesEquip, BorderLayout.SOUTH);
        add(panelGrupos); add(panelEquip);
        btnAgregarGrupo.addActionListener(e -> {
            String nombre = JOptionPane.showInputDialog(this, "Nueva categoría de grupo:");
            if (nombre != null && !nombre.trim().isEmpty()) {
                ejercicioManager.agregarCategoriaGrupo(nombre.trim());
                modeloGrupos.addElement(nombre.trim());
            }
        });
        btnRenombrarGrupo.addActionListener(e -> {
            int idx = listaGrupos.getSelectedIndex();
            if (idx >= 0) {
                String nuevo = JOptionPane.showInputDialog(this, "Nuevo nombre:", modeloGrupos.get(idx));
                if (nuevo != null && !nuevo.trim().isEmpty()) {
                    ejercicioManager.renombrarCategoriaGrupo(modeloGrupos.get(idx), nuevo.trim());
                    modeloGrupos.set(idx, nuevo.trim());
                }
            }
        });
        btnEliminarGrupo.addActionListener(e -> {
            int idx = listaGrupos.getSelectedIndex();
            if (idx >= 0) {
                ejercicioManager.eliminarCategoriaGrupo(modeloGrupos.get(idx));
                modeloGrupos.remove(idx);
            }
        });
        btnAgregarEquip.addActionListener(e -> {
            String nombre = JOptionPane.showInputDialog(this, "Nueva categoría de equipamiento:");
            if (nombre != null && !nombre.trim().isEmpty()) {
                ejercicioManager.agregarCategoriaEquipamiento(nombre.trim());
                modeloEquip.addElement(nombre.trim());
            }
        });
        btnRenombrarEquip.addActionListener(e -> {
            int idx = listaEquip.getSelectedIndex();
            if (idx >= 0) {
                String nuevo = JOptionPane.showInputDialog(this, "Nuevo nombre:", modeloEquip.get(idx));
                if (nuevo != null && !nuevo.trim().isEmpty()) {
                    ejercicioManager.renombrarCategoriaEquipamiento(modeloEquip.get(idx), nuevo.trim());
                    modeloEquip.set(idx, nuevo.trim());
                }
            }
        });
        btnEliminarEquip.addActionListener(e -> {
            int idx = listaEquip.getSelectedIndex();
            if (idx >= 0) {
                ejercicioManager.eliminarCategoriaEquipamiento(modeloEquip.get(idx));
                modeloEquip.remove(idx);
            }
        });
    }
}
