import modelo.Usuario;
// Interfaz para edición de perfil y cambio de contraseña
public class InterfazPerfil {
    public void mostrarPerfil(Usuario usuario) {
        System.out.println("--- Mi Perfil ---");
        System.out.println("Nombre: " + usuario.getNombre());
        System.out.println("Apellido: " + usuario.getApellido());
        System.out.println("Correo: " + usuario.getCorreo());
    }
    public void mostrarEdicionPerfil(Usuario usuario) {
        System.out.println("Editar perfil (nombre, apellido, correo)");
        // Aquí iría la lógica para editar los datos
    }
    public void mostrarCambioContraseña(Usuario usuario) {
        System.out.println("Cambiar contraseña");
        // Aquí iría la lógica para cambiar la contraseña
    }
}
