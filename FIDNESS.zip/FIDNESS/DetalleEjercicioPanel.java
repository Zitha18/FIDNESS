import javax.swing.*;
import java.awt.*;

// Panel para mostrar detalle de ejercicio
public class DetalleEjercicioPanel extends JDialog {
    public DetalleEjercicioPanel(JFrame parent, Ejercicio ejercicio, EjercicioManager ejercicioManager) {
        super(parent, "Detalle de Ejercicio", true);
        setSize(400, 300);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(6, 1));
        add(new JLabel("Nombre: " + ejercicio.getNombre()));
        add(new JLabel("Grupos: " + String.join(", ", ejercicio.getGruposMusculares())));
        add(new JLabel("Equipamiento: " + String.join(", ", ejercicio.getEquipamiento())));
        add(new JLabel("Descripción: " + ejercicio.getDescripcion()));
        add(new JLabel("Consejos: " + String.join(", ", ejercicio.getConsejos())));
        add(new JLabel("Errores Comunes: " + String.join(", ", ejercicio.getErroresComunes())));
        // Aquí iría el botón para marcar como favorito
    }
}
