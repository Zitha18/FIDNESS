import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

// Panel para editar rutina
public class EditarRutinaPanel extends JDialog {
    public EditarRutinaPanel(JFrame parent, Rutina rutina, EjercicioManager ejercicioManager, RutinaManager rutinaManager, Runnable actualizarLista) {
        super(parent, "Editar Rutina", true);
        setSize(500, 400);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        DefaultListModel<EjercicioEnRutina> modeloEjercicios = new DefaultListModel<>();
        JList<EjercicioEnRutina> listaEjercicios = new JList<>(modeloEjercicios);
        listaEjercicios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(listaEjercicios);
        add(scroll, BorderLayout.CENTER);

        JButton btnAgregar = new JButton("Agregar Ejercicio");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnArriba = new JButton("Arriba");
        JButton btnAbajo = new JButton("Abajo");
        JButton btnNota = new JButton("Nota");
        JPanel panelBotones = new JPanel();
        panelBotones.add(btnAgregar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnArriba);
        panelBotones.add(btnAbajo);
        panelBotones.add(btnNota);
        add(panelBotones, BorderLayout.SOUTH);

        Runnable actualizarEjercicios = () -> {
            modeloEjercicios.clear();
            for (EjercicioEnRutina er : rutina.getEjercicios()) modeloEjercicios.addElement(er);
        };
        actualizarEjercicios.run();

        btnAgregar.addActionListener(e -> {
            List<Ejercicio> ejercicios = ejercicioManager.getListaEjercicios();
            Ejercicio seleccionado = (Ejercicio) JOptionPane.showInputDialog(this, "Selecciona ejercicio:", "Agregar", JOptionPane.PLAIN_MESSAGE, null, ejercicios.toArray(), null);
            if (seleccionado != null) {
                String nota = JOptionPane.showInputDialog(this, "Nota para el ejercicio (opcional):");
                rutina.agregarEjercicio(seleccionado, nota);
                rutinaManager.guardarRutinas();
                actualizarEjercicios.run();
                actualizarLista.run();
            }
        });
        btnEliminar.addActionListener(e -> {
            int idx = listaEjercicios.getSelectedIndex();
            if (idx >= 0) {
                rutina.eliminarEjercicio(idx);
                rutinaManager.guardarRutinas();
                actualizarEjercicios.run();
                actualizarLista.run();
            }
        });
        btnArriba.addActionListener(e -> {
            int idx = listaEjercicios.getSelectedIndex();
            if (idx > 0) {
                rutina.moverEjercicio(idx, idx - 1);
                rutinaManager.guardarRutinas();
                actualizarEjercicios.run();
                listaEjercicios.setSelectedIndex(idx - 1);
            }
        });
        btnAbajo.addActionListener(e -> {
            int idx = listaEjercicios.getSelectedIndex();
            if (idx >= 0 && idx < modeloEjercicios.size() - 1) {
                rutina.moverEjercicio(idx, idx + 1);
                rutinaManager.guardarRutinas();
                actualizarEjercicios.run();
                listaEjercicios.setSelectedIndex(idx + 1);
            }
        });
        btnNota.addActionListener(e -> {
            int idx = listaEjercicios.getSelectedIndex();
            if (idx >= 0) {
                EjercicioEnRutina er = modeloEjercicios.get(idx);
                String nota = JOptionPane.showInputDialog(this, "Editar nota:", er.getNota());
                if (nota != null) {
                    rutina.setNotaEjercicio(idx, nota);
                    rutinaManager.guardarRutinas();
                    actualizarEjercicios.run();
                }
            }
        });
    }
}
