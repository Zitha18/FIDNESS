import javax.swing.*;
import java.awt.*;
import java.util.*;

// GUI para registrar entrenamiento
public class InterfazEntrenamiento extends JFrame {
    public InterfazEntrenamiento(Rutina rutina, HistorialManager historialManager) {
        setTitle("Modo Entrenamiento: " + rutina.getNombre());
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        DefaultListModel<EjercicioEnRutina> modeloEjercicios = new DefaultListModel<>();
        JList<EjercicioEnRutina> listaEjercicios = new JList<>(modeloEjercicios);
        listaEjercicios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(listaEjercicios);
        add(scroll, BorderLayout.CENTER);

        JButton btnRegistrar = new JButton("Registrar Series");
        JButton btnFinalizar = new JButton("Finalizar Entrenamiento");
        JPanel panelBotones = new JPanel();
        panelBotones.add(btnRegistrar);
        panelBotones.add(btnFinalizar);
        add(panelBotones, BorderLayout.SOUTH);

        for (EjercicioEnRutina er : rutina.getEjercicios()) modeloEjercicios.addElement(er);

        RegistroEntrenamiento registro = new RegistroEntrenamiento(new Date(), rutina.getNombre());
        Map<String, EjercicioRealizado> realizados = new HashMap<>();
        for (EjercicioEnRutina er : rutina.getEjercicios()) {
            realizados.put(er.getEjercicio().getNombre(), new EjercicioRealizado(er.getEjercicio().getNombre()));
        }

        btnRegistrar.addActionListener(e -> {
            int idx = listaEjercicios.getSelectedIndex();
            if (idx >= 0) {
                EjercicioEnRutina er = modeloEjercicios.get(idx);
                String input = JOptionPane.showInputDialog(this, "Ingrese series (ej: 3x12x50 para 3 series de 12 reps con 50kg):");
                if (input != null && !input.trim().isEmpty()) {
                    String[] partes = input.split("x");
                    if (partes.length == 3) {
                        int numSeries = Integer.parseInt(partes[0]);
                        int reps = Integer.parseInt(partes[1]);
                        double peso = Double.parseDouble(partes[2]);
                        EjercicioRealizado realizado = realizados.get(er.getEjercicio().getNombre());
                        for (int i = 1; i <= numSeries; i++) {
                            realizado.agregarSerie(new SerieEjercicio(i, reps, peso));
                        }
                    }
                }
            }
        });
        btnFinalizar.addActionListener(e -> {
            for (EjercicioRealizado realizado : realizados.values()) {
                registro.agregarEjercicioRealizado(realizado);
            }
            historialManager.agregarRegistro(registro);
            JOptionPane.showMessageDialog(this, "Entrenamiento registrado");
            dispose();
        });
    }
}
