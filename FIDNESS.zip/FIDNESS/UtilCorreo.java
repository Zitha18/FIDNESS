// Utilidad para simular envío de correo
public class UtilCorreo {
    public static boolean enviarCorreoRecuperacion(String correo, String enlace) {
        System.out.println("Simulando envío de correo a " + correo + " con enlace: " + enlace);
        return true;
    }
}
