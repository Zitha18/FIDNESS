package servidor;
// Clase base para el servidor
import java.net.*;
import java.io.*;
import persistencia.EjercicioDAO;
import modelo.Ejercicio;
import red.Request;
import red.Response;
import persistencia.UsuarioDAO;
import modelo.Usuario;
import persistencia.RutinaDAO;
import modelo.Rutina;
import persistencia.HistorialDAO;
import modelo.Historial;
import persistencia.CategoriaDAO;
import modelo.Categoria;
import persistencia.AnuncioDAO;
import modelo.Anuncio;
import persistencia.PreguntaDAO;
import modelo.Pregunta;
import persistencia.InformacionGimnasioDAO;
import modelo.InformacionGimnasio;

public class ServidorSocket {
    public static void main(String[] args) {
    int puerto = 1527;
    EjercicioDAO ejercicioDAO = new EjercicioDAO();
    ejercicioDAO.crearTabla(); // Asegura que la tabla exista
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        usuarioDAO.crearTabla();
        RutinaDAO rutinaDAO = new RutinaDAO();
        rutinaDAO.crearTabla();
        HistorialDAO historialDAO = new HistorialDAO();
        historialDAO.crearTabla();
        CategoriaDAO categoriaDAO = new CategoriaDAO();
        categoriaDAO.crearTabla();
        AnuncioDAO anuncioDAO = new AnuncioDAO();
        anuncioDAO.crearTabla();
        PreguntaDAO preguntaDAO = new PreguntaDAO();
        preguntaDAO.crearTabla();
        InformacionGimnasioDAO infoDAO = new InformacionGimnasioDAO();
        infoDAO.crearTabla();
        try (ServerSocket serverSocket = new ServerSocket(puerto)) {
            System.out.println("Servidor iniciado en puerto " + puerto);
            while (true) {
                Socket cliente = serverSocket.accept();
                new Thread(() -> manejarCliente(cliente, ejercicioDAO, usuarioDAO, rutinaDAO, historialDAO, categoriaDAO, anuncioDAO, preguntaDAO, infoDAO)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private static void manejarCliente(Socket cliente, EjercicioDAO ejercicioDAO, UsuarioDAO usuarioDAO, RutinaDAO rutinaDAO, HistorialDAO historialDAO, CategoriaDAO categoriaDAO, AnuncioDAO anuncioDAO, PreguntaDAO preguntaDAO, InformacionGimnasioDAO infoDAO) {
        try (ObjectInputStream in = new ObjectInputStream(cliente.getInputStream());
             ObjectOutputStream out = new ObjectOutputStream(cliente.getOutputStream())) {
            Object obj = in.readObject();
            if (obj instanceof Request) {
                Request req = (Request) obj;
                Response resp = procesarRequest(req, ejercicioDAO, usuarioDAO, rutinaDAO, historialDAO, categoriaDAO, anuncioDAO, preguntaDAO, infoDAO);
                out.writeObject(resp);
            } else {
                out.writeObject(new Response(false, null, "Petición inválida"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private static Response procesarRequest(Request req, EjercicioDAO ejercicioDAO, UsuarioDAO usuarioDAO, RutinaDAO rutinaDAO, HistorialDAO historialDAO, CategoriaDAO categoriaDAO, AnuncioDAO anuncioDAO, PreguntaDAO preguntaDAO, InformacionGimnasioDAO infoDAO) {
            // ...existing code...
        try {
            switch (req.accion) {
                // --- Login de usuario ---
                case "loginUsuario":
                    // req.datos debe ser un arreglo [correo, password]
                    Object[] loginData = (Object[]) req.datos;
                    String correo = (String) loginData[0];
                    String password = (String) loginData[1];
                    Usuario usuario = usuarioDAO.loginUsuario(correo, password);
                    if (usuario != null) {
                        return new Response(true, usuario, "Login exitoso");
                    } else {
                        return new Response(false, null, "Credenciales incorrectas");
                    }
                // --- Registro de usuario ---
                case "registrarUsuario":
                    Usuario nuevoUsuario = (Usuario) req.datos;
                    boolean okRegistro = usuarioDAO.agregarUsuario(nuevoUsuario);
                    return new Response(okRegistro, null, okRegistro ? "Usuario registrado" : "Error al registrar usuario");
                // Ejercicios
                case "agregarEjercicio":
                    Ejercicio ejAdd = (Ejercicio) req.datos;
                    boolean okAdd = ejercicioDAO.agregarEjercicio(ejAdd);
                    return new Response(okAdd, null, okAdd ? "Ejercicio agregado" : "Error al agregar");
                case "obtenerEjercicio":
                    int idGet = (int) req.datos;
                    Ejercicio ejGet = ejercicioDAO.obtenerPorId(idGet);
                    return new Response(ejGet != null, ejGet, ejGet != null ? "Encontrado" : "No existe");
                case "obtenerTodosEjercicios":
                    java.util.List<Ejercicio> lista = ejercicioDAO.obtenerTodos();
                    return new Response(true, lista, "Lista de ejercicios");
                case "actualizarEjercicio":
                    Ejercicio ejUpd = (Ejercicio) req.datos;
                    boolean okUpd = ejercicioDAO.actualizarEjercicio(ejUpd);
                    return new Response(okUpd, null, okUpd ? "Ejercicio actualizado" : "Error al actualizar");
                case "eliminarEjercicio":
                    int idDel = (int) req.datos;
                    boolean okDel = ejercicioDAO.eliminarEjercicio(idDel);
                    return new Response(okDel, null, okDel ? "Ejercicio eliminado" : "Error al eliminar");
                // Usuarios
                case "agregarUsuario":
                    Usuario uAdd = (Usuario) req.datos;
                    boolean okUAdd = usuarioDAO.agregarUsuario(uAdd);
                    return new Response(okUAdd, null, okUAdd ? "Usuario agregado" : "Error al agregar usuario");
                case "obtenerUsuario":
                    int idUGet = (int) req.datos;
                    Usuario uGet = usuarioDAO.obtenerPorId(idUGet);
                    return new Response(uGet != null, uGet, uGet != null ? "Usuario encontrado" : "No existe usuario");
                case "obtenerTodosUsuarios":
                    java.util.List<Usuario> listaU = usuarioDAO.obtenerTodos();
                    return new Response(true, listaU, "Lista de usuarios");
                case "actualizarUsuario":
                    Usuario uUpd = (Usuario) req.datos;
                    boolean okUUpd = usuarioDAO.actualizarUsuario(uUpd);
                    return new Response(okUUpd, null, okUUpd ? "Usuario actualizado" : "Error al actualizar usuario");
                case "eliminarUsuario":
                    int idUDel = (int) req.datos;
                    boolean okUDel = usuarioDAO.eliminarUsuario(idUDel);
                    return new Response(okUDel, null, okUDel ? "Usuario eliminado" : "Error al eliminar usuario");
                // Rutinas
                case "agregarRutina":
                    Rutina rAdd = (Rutina) req.datos;
                    boolean okRAdd = rutinaDAO.agregarRutina(rAdd);
                    return new Response(okRAdd, null, okRAdd ? "Rutina agregada" : "Error al agregar rutina");
                case "obtenerRutina":
                    int idRGet = (int) req.datos;
                    Rutina rGet = rutinaDAO.obtenerPorId(idRGet);
                    return new Response(rGet != null, rGet, rGet != null ? "Rutina encontrada" : "No existe rutina");
                case "obtenerTodasRutinas":
                    java.util.List<Rutina> listaR = rutinaDAO.obtenerTodas();
                    return new Response(true, listaR, "Lista de rutinas");
                case "actualizarRutina":
                    Rutina rUpd = (Rutina) req.datos;
                    boolean okRUpd = rutinaDAO.actualizarRutina(rUpd);
                    return new Response(okRUpd, null, okRUpd ? "Rutina actualizada" : "Error al actualizar rutina");
                case "eliminarRutina":
                    int idRDel = (int) req.datos;
                    boolean okRDel = rutinaDAO.eliminarRutina(idRDel);
                    return new Response(okRDel, null, okRDel ? "Rutina eliminada" : "Error al eliminar rutina");
                // Historial
                case "agregarHistorial":
                    Historial hAdd = (Historial) req.datos;
                    boolean okHAdd = historialDAO.agregarHistorial(hAdd);
                    return new Response(okHAdd, null, okHAdd ? "Historial agregado" : "Error al agregar historial");
                case "obtenerHistorial":
                    int idHGet = (int) req.datos;
                    Historial hGet = historialDAO.obtenerPorId(idHGet);
                    return new Response(hGet != null, hGet, hGet != null ? "Historial encontrado" : "No existe historial");
                case "obtenerTodosHistoriales":
                    java.util.List<Historial> listaH = historialDAO.obtenerTodos();
                    return new Response(true, listaH, "Lista de historiales");
                case "actualizarHistorial":
                    Historial hUpd = (Historial) req.datos;
                    boolean okHUpd = historialDAO.actualizarHistorial(hUpd);
                    return new Response(okHUpd, null, okHUpd ? "Historial actualizado" : "Error al actualizar historial");
                case "eliminarHistorial":
                    int idHDel = (int) req.datos;
                    boolean okHDel = historialDAO.eliminarHistorial(idHDel);
                    return new Response(okHDel, null, okHDel ? "Historial eliminado" : "Error al eliminar historial");
                // Categoría
                case "agregarCategoria":
                    Categoria cAdd = (Categoria) req.datos;
                    boolean okCAdd = categoriaDAO.agregarCategoria(cAdd);
                    return new Response(okCAdd, null, okCAdd ? "Categoría agregada" : "Error al agregar categoría");
                case "obtenerCategoria":
                    int idCGet = (int) req.datos;
                    Categoria cGet = categoriaDAO.obtenerPorId(idCGet);
                    return new Response(cGet != null, cGet, cGet != null ? "Categoría encontrada" : "No existe categoría");
                case "obtenerTodasCategorias":
                    java.util.List<Categoria> listaC = categoriaDAO.obtenerTodas();
                    return new Response(true, listaC, "Lista de categorías");
                case "actualizarCategoria":
                    Categoria cUpd = (Categoria) req.datos;
                    boolean okCUpd = categoriaDAO.actualizarCategoria(cUpd);
                    return new Response(okCUpd, null, okCUpd ? "Categoría actualizada" : "Error al actualizar categoría");
                case "eliminarCategoria":
                    int idCDel = (int) req.datos;
                    boolean okCDel = categoriaDAO.eliminarCategoria(idCDel);
                    return new Response(okCDel, null, okCDel ? "Categoría eliminada" : "Error al eliminar categoría");
                // Anuncio
                case "agregarAnuncio":
                    Anuncio aAdd = (Anuncio) req.datos;
                    boolean okAAdd = anuncioDAO.agregarAnuncio(aAdd);
                    return new Response(okAAdd, null, okAAdd ? "Anuncio agregado" : "Error al agregar anuncio");
                case "obtenerAnuncio":
                    int idAGet = (int) req.datos;
                    Anuncio aGet = anuncioDAO.obtenerPorId(idAGet);
                    return new Response(aGet != null, aGet, aGet != null ? "Anuncio encontrado" : "No existe anuncio");
                case "obtenerTodosAnuncios":
                    java.util.List<Anuncio> listaA = anuncioDAO.obtenerTodos();
                    return new Response(true, listaA, "Lista de anuncios");
                case "actualizarAnuncio":
                    Anuncio aUpd = (Anuncio) req.datos;
                    boolean okAUpd = anuncioDAO.actualizarAnuncio(aUpd);
                    return new Response(okAUpd, null, okAUpd ? "Anuncio actualizado" : "Error al actualizar anuncio");
                case "eliminarAnuncio":
                    int idADel = (int) req.datos;
                    boolean okADel = anuncioDAO.eliminarAnuncio(idADel);
                    return new Response(okADel, null, okADel ? "Anuncio eliminado" : "Error al eliminar anuncio");
                // Pregunta
                // --- Pregunta: agregar, obtener, actualizar, listar, eliminar ---
                case "agregarPregunta":
                    Pregunta pAdd = (Pregunta) req.datos;
                    boolean okPAdd = preguntaDAO.agregarPregunta(pAdd);
                    return new Response(okPAdd, null, okPAdd ? "Pregunta agregada" : "Error al agregar pregunta");
                case "obtenerPregunta":
                    int idPGet = (int) req.datos;
                    Pregunta pGet = preguntaDAO.obtenerPorId(idPGet);
                    return new Response(pGet != null, pGet, pGet != null ? "Pregunta encontrada" : "No existe pregunta");
                case "obtenerTodasPreguntas":
                    java.util.List<Pregunta> listaP = preguntaDAO.obtenerTodas();
                    return new Response(true, listaP, "Lista de preguntas");
                case "actualizarPregunta":
                    Pregunta pUpd = (Pregunta) req.datos;
                    boolean okPUpd = preguntaDAO.actualizarPregunta(pUpd);
                    return new Response(okPUpd, null, okPUpd ? "Pregunta actualizada" : "Error al actualizar pregunta");
                case "eliminarPregunta":
                    int idPDel = (int) req.datos;
                    boolean okPDel = preguntaDAO.eliminarPregunta(idPDel);
                    return new Response(okPDel, null, okPDel ? "Pregunta eliminada" : "Error al eliminar pregunta");
                // InformacionGimnasio
                // --- InformacionGimnasio: agregar, obtener, actualizar, listar, eliminar ---
                case "agregarInformacion":
                    InformacionGimnasio iAdd = (InformacionGimnasio) req.datos;
                    boolean okIAdd = infoDAO.agregarInformacion(iAdd);
                    return new Response(okIAdd, null, okIAdd ? "Información agregada" : "Error al agregar información");
                case "obtenerInformacion":
                    int idIGet = (int) req.datos;
                    InformacionGimnasio iGet = infoDAO.obtenerPorId(idIGet);
                    return new Response(iGet != null, iGet, iGet != null ? "Información encontrada" : "No existe información");
                case "obtenerTodaInformacion":
                    java.util.List<InformacionGimnasio> listaI = infoDAO.obtenerTodas();
                    return new Response(true, listaI, "Lista de información");
                case "actualizarInformacion":
                    InformacionGimnasio iUpd = (InformacionGimnasio) req.datos;
                    boolean okIUpd = infoDAO.actualizarInformacion(iUpd);
                    return new Response(okIUpd, null, okIUpd ? "Información actualizada" : "Error al actualizar información");
                case "eliminarInformacion":
                    int idIDel = (int) req.datos;
                    boolean okIDel = infoDAO.eliminarInformacion(idIDel);
                    return new Response(okIDel, null, okIDel ? "Información eliminada" : "Error al eliminar información");
                default:
                    return new Response(false, null, "Acción desconocida");
            }
        } catch (Exception e) {
            return new Response(false, null, "Error interno: " + e.getMessage());
        }
    }
}
