import modelo.Usuario;
import javax.swing.*;
import java.awt.*;
// ...existing code...

// Panel para inicio de sesión
public class LoginPanel extends JDialog {
    private UsuarioManager usuarioManager;
    private SesionManager sesionManager;

    public LoginPanel(JFrame parent, UsuarioManager usuarioManager, SesionManager sesionManager) {
        super(parent, "Iniciar Sesión", true);
        this.usuarioManager = usuarioManager;
        this.sesionManager = sesionManager;
        setSize(300, 200);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(4, 2));

        JLabel lblCorreo = new JLabel("Correo:");
        JTextField txtCorreo = new JTextField();
        JLabel lblPass = new JLabel("Contraseña:");
        JPasswordField txtPass = new JPasswordField();
        JCheckBox chkRecordar = new JCheckBox("Recordarme");
        JButton btnIngresar = new JButton("Ingresar");
        JButton btnCancelar = new JButton("Cancelar");

        add(lblCorreo); add(txtCorreo);
        add(lblPass); add(txtPass);
        add(chkRecordar); add(new JLabel());
        add(btnIngresar); add(btnCancelar);

    btnIngresar.addActionListener(_unused -> {
        String correo = txtCorreo.getText();
        String pass = new String(txtPass.getPassword());
        boolean recordarme = chkRecordar.isSelected();
        btnIngresar.setEnabled(false);
        btnCancelar.setEnabled(false);
        SwingWorker<Usuario, Void> worker = new SwingWorker<>() {
            @Override
            protected Usuario doInBackground() {
                return usuarioManager.iniciarSesion(correo, pass);
            }
            @Override
            protected void done() {
                btnIngresar.setEnabled(true);
                btnCancelar.setEnabled(true);
                try {
                    Usuario u = get();
                    if (u != null) {
                        sesionManager.iniciarSesion(u, recordarme);
                        JOptionPane.showMessageDialog(LoginPanel.this, "Bienvenido " + u.getNombre());
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(LoginPanel.this, "Credenciales incorrectas");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(LoginPanel.this, "Error de conexión: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    });
    btnCancelar.addActionListener(_unused -> dispose());
    }
}
