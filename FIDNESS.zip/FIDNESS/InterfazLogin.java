import modelo.Usuario;
import java.util.Scanner;

// Interfaz para el login
public class InterfazLogin {
    private UsuarioManager usuarioManager;
    private SesionManager sesionManager;

    public InterfazLogin(UsuarioManager usuarioManager, SesionManager sesionManager) {
        this.usuarioManager = usuarioManager;
        this.sesionManager = sesionManager;
    }

    public void mostrarLogin() {
    Scanner sc = new Scanner(System.in);
        System.out.println("--- Inicio de Sesión ---");
        System.out.print("Correo: ");
        String correo = sc.nextLine();
        System.out.print("Contraseña: ");
        String contraseña = sc.nextLine();
        System.out.print("Recordarme (s/n): ");
        String rec = sc.nextLine();
        boolean recordarme = rec.equalsIgnoreCase("s");
        Usuario u = usuarioManager.iniciarSesion(correo, contraseña);
        if (u != null) {
            sesionManager.iniciarSesion(u, recordarme);
            System.out.println("Bienvenido " + u.getNombre());
        } else {
            System.out.println("Credenciales incorrectas");
        }
    sc.close();
    }

    public void mostrarRecordarSesion() {
        if (sesionManager.sesionActiva() && sesionManager.obtenerUsuarioActual().isRecordarme()) {
            System.out.println("Sesión recordada para " + sesionManager.obtenerUsuarioActual().getCorreo());
        }
    }

    public void mostrarRecuperarPassword() {
    Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese su correo para recuperar contraseña: ");
        String correo = sc.nextLine();
        if (usuarioManager.enviarRecuperacion(correo)) {
            System.out.println("Se ha enviado un correo de recuperación a " + correo);
        } else {
            System.out.println("Correo no encontrado");
        }
    sc.close();
    }
}
