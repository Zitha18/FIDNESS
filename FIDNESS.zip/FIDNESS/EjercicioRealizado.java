import java.util.*;

// Modelo de ejercicio realizado en un entrenamiento
public class EjercicioRealizado {
    private String nombreEjercicio;
    private List<SerieEjercicio> series;

    public EjercicioRealizado(String nombreEjercicio) {
        this.nombreEjercicio = nombreEjercicio;
        this.series = new ArrayList<>();
    }
    public String getNombreEjercicio() { return nombreEjercicio; }
    public List<SerieEjercicio> getSeries() { return series; }
    public void agregarSerie(SerieEjercicio serie) { series.add(serie); }
    public String toString() {
        return nombreEjercicio + " - " + series.size() + " series";
    }
}
