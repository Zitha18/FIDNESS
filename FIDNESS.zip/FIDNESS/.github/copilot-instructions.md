# Reglas del Proyecto para Generar Código en GitHub Copilot

- Arregla lo que te pido
- Explicame por qué hiciste esos cambios
- Dime por que no funcionan
