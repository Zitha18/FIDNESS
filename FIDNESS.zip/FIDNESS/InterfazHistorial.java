import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.ArrayList;
import java.util.Date;

// GUI para ver historial de entrenamientos
public class InterfazHistorial extends JFrame {
    public InterfazHistorial(HistorialManager historialManager) {
        setTitle("Historial de Entrenamientos");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        DefaultListModel<String> modeloFechas = new DefaultListModel<>();
        JList<String> listaFechas = new JList<>(modeloFechas);
        listaFechas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollFechas = new JScrollPane(listaFechas);
        add(scrollFechas, BorderLayout.WEST);

        DefaultListModel<String> modeloEntrenamientos = new DefaultListModel<>();
        JList<String> listaEntrenamientos = new JList<>(modeloEntrenamientos);
        JScrollPane scrollEntrenamientos = new JScrollPane(listaEntrenamientos);
        add(scrollEntrenamientos, BorderLayout.CENTER);

        DefaultListModel<String> modeloEjercicios = new DefaultListModel<>();
        JList<String> listaEjercicios = new JList<>(modeloEjercicios);
        JScrollPane scrollEjercicios = new JScrollPane(listaEjercicios);
        add(scrollEjercicios, BorderLayout.EAST);

        Set<String> fechas = new TreeSet<>();
        for (RegistroEntrenamiento r : historialManager.getHistorialCompleto()) {
            fechas.add(new java.text.SimpleDateFormat("yyyy-MM-dd").format(r.getFecha()));
        }
        for (String f : fechas) modeloFechas.addElement(f);

        List<RegistroEntrenamiento> entrenamientosMostrados = new ArrayList<>();

        listaFechas.addListSelectionListener(e -> {
            modeloEntrenamientos.clear();
            modeloEjercicios.clear();
            entrenamientosMostrados.clear();
            if (!e.getValueIsAdjusting()) {
                String fechaStr = listaFechas.getSelectedValue();
                try {
                    Date fecha = new java.text.SimpleDateFormat("yyyy-MM-dd").parse(fechaStr);
                    for (RegistroEntrenamiento r : historialManager.getHistorialPorFecha(fecha)) {
                        modeloEntrenamientos.addElement(r.getNombreRutina() + " - " + r.getFecha());
                        entrenamientosMostrados.add(r);
                    }
                } catch (Exception ex) {}
            }
        });

        listaEntrenamientos.addListSelectionListener(e -> {
            modeloEjercicios.clear();
            int idx = listaEntrenamientos.getSelectedIndex();
            if (idx >= 0 && idx < entrenamientosMostrados.size()) {
                RegistroEntrenamiento r = entrenamientosMostrados.get(idx);
                for (EjercicioRealizado er : r.getEjerciciosRealizados()) {
                    modeloEjercicios.addElement(er.getNombreEjercicio());
                }
            }
        });
    }
}
