// Modelo de una serie de ejercicio
public class SerieEjercicio {
    private int numeroSerie;
    private int repeticiones;
    private double peso;

    public SerieEjercicio(int numeroSerie, int repeticiones, double peso) {
        this.numeroSerie = numeroSerie;
        this.repeticiones = repeticiones;
        this.peso = peso;
    }
    public int getNumeroSerie() { return numeroSerie; }
    public int getRepeticiones() { return repeticiones; }
    public double getPeso() { return peso; }
    public void setRepeticiones(int repeticiones) { this.repeticiones = repeticiones; }
    public void setPeso(double peso) { this.peso = peso; }
    public String toString() {
        return "Serie " + numeroSerie + ": " + repeticiones + " reps, " + peso + " kg";
    }
}
