import modelo.Usuario;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

// Ventana principal de la app Fidness
public class FidnessGUI extends JFrame {
    private UsuarioManager usuarioManager;
    private SesionManager sesionManager;
    private EjercicioManager ejercicioManager;
    private AnuncioManager anuncioManager;
    private PreguntaManager preguntaManager;
    private InformacionGimnasioManager infoManager;

    public FidnessGUI() {
        usuarioManager = new UsuarioManager();
        sesionManager = new SesionManager();
        ejercicioManager = new EjercicioManager();
        anuncioManager = new AnuncioManager();
        preguntaManager = new PreguntaManager();
        infoManager = new InformacionGimnasioManager();
        anuncioManager.cargarAnuncios();
        preguntaManager.cargarPreguntas();
        infoManager.cargarInformacion();
        setTitle("Fidness - Gimnasio");
        setSize(400, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(15, 1));

    JButton btnLogin = new JButton("Iniciar Sesión");
    JButton btnRegistrar = new JButton("Registrar Usuario");
        JButton btnRecordar = new JButton("Recordar Sesión");
        JButton btnRecuperar = new JButton("Recuperar Contraseña");
        JButton btnPerfil = new JButton("Ver Perfil");
        JButton btnEjercicios = new JButton("Ejercicios");
        JButton btnEjerciciosFavoritos = new JButton("Ejercicios Favoritos");
        JButton btnRutinas = new JButton("Rutinas");
        JButton btnDashboard = new JButton("Dashboard");
        JButton btnHistorial = new JButton("Historial");
        JButton btnProgreso = new JButton("Progreso Ejercicio");
        JButton btnEntrenamiento = new JButton("Modo Entrenamiento");
        JButton btnAnuncios = new JButton("Anuncios del Gimnasio");
        JButton btnPreguntas = new JButton("Soporte: Preguntas");
        JButton btnInfoGimnasio = new JButton("Información del Gimnasio");
        JButton btnAdminEjercicios = new JButton("Admin: Ejercicios");
        JButton btnAdminCategorias = new JButton("Admin: Categorías");
        JButton btnSalir = new JButton("Salir");

    add(btnLogin);
    add(btnRegistrar);
    add(btnRecordar);
        add(btnRecuperar);
        add(btnPerfil);
        add(btnEjercicios);
        add(btnEjerciciosFavoritos);
        add(btnRutinas);
        add(btnDashboard);
        add(btnHistorial);
        add(btnProgreso);
        add(btnEntrenamiento);
        add(btnAnuncios);
        add(btnPreguntas);
        add(btnInfoGimnasio);
    // Los botones de admin son visibles para todos, pero solo accesibles para administradores
    add(btnAdminEjercicios);
    add(btnAdminCategorias);
    add(btnSalir);

        btnLogin.addActionListener(e -> {
            new LoginPanel(this, usuarioManager, sesionManager).setVisible(true);
        });
        btnRegistrar.addActionListener(e -> {
            new RegistroPanel(this, usuarioManager).setVisible(true);
        });
        btnRecordar.addActionListener(e -> {
            if (sesionManager.sesionActiva() && sesionManager.obtenerUsuarioActual().isRecordarme()) {
                JOptionPane.showMessageDialog(this, "Sesión recordada para " + sesionManager.obtenerUsuarioActual().getCorreo());
            } else {
                JOptionPane.showMessageDialog(this, "No hay sesión recordada");
            }
        });
        btnRecuperar.addActionListener(e -> {
            new RecuperarPasswordPanel(this, usuarioManager).setVisible(true);
        });
        btnPerfil.addActionListener(e -> {
            if (sesionManager.sesionActiva()) {
                new PerfilPanel((JFrame) this, (Usuario) sesionManager.obtenerUsuarioActual()).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Debe iniciar sesión primero.");
            }
        });
        btnEjercicios.addActionListener(e -> {
            new InterfazEjercicios(ejercicioManager).setVisible(true);
        });
        btnRutinas.addActionListener(e -> {
            RutinaManager rutinaManager = new RutinaManager();
            new InterfazRutinas(rutinaManager, ejercicioManager).setVisible(true);
        });
        btnDashboard.addActionListener(e -> {
            HistorialManager historialManager = new HistorialManager();
            JFrame dashFrame = new JFrame("Dashboard");
            dashFrame.setSize(400, 200);
            dashFrame.setLocationRelativeTo(this);
            dashFrame.add(new InterfazDashboard(historialManager));
            dashFrame.setVisible(true);
        });
        btnHistorial.addActionListener(e -> {
            HistorialManager historialManager = new HistorialManager();
            new InterfazHistorial(historialManager).setVisible(true);
        });
        btnProgreso.addActionListener(e -> {
            HistorialManager historialManager = new HistorialManager();
            String nombreEjercicio = JOptionPane.showInputDialog(this, "Nombre del ejercicio para ver progreso:");
            if (nombreEjercicio != null && !nombreEjercicio.trim().isEmpty()) {
                new InterfazProgresoEjercicio(historialManager, nombreEjercicio.trim()).setVisible(true);
            }
        });
        btnEntrenamiento.addActionListener(e -> {
            RutinaManager rutinaManager = new RutinaManager();
            HistorialManager historialManager = new HistorialManager();
            List<Rutina> rutinas = rutinaManager.getListaRutinas();
            Rutina seleccionada = (Rutina) JOptionPane.showInputDialog(this, "Selecciona rutina:", "Entrenamiento", JOptionPane.PLAIN_MESSAGE, null, rutinas.toArray(), null);
            if (seleccionada != null) {
                new InterfazEntrenamiento(seleccionada, historialManager).setVisible(true);
            }
        });
        btnEjerciciosFavoritos.addActionListener(e -> {
            InterfazEjercicios favoritosGUI = new InterfazEjercicios(ejercicioManager, true);
            favoritosGUI.setVisible(true);
        });
        btnAnuncios.addActionListener(e -> {
            JFrame frame = new JFrame("Anuncios del Gimnasio");
            frame.setSize(400, 300);
            frame.setLocationRelativeTo(this);
            Usuario usuarioActualPanel = (Usuario) sesionManager.obtenerUsuarioActual();
            frame.add(new PanelAnuncios(anuncioManager, usuarioActualPanel));
            frame.setVisible(true);
        });
        btnPreguntas.addActionListener(e -> {
            JFrame frame = new JFrame("Soporte: Preguntas");
            frame.setSize(400, 300);
            frame.setLocationRelativeTo(this);
            Usuario usuarioActualPanel = sesionManager.obtenerUsuarioActual();
            frame.add(new PanelPreguntas(preguntaManager, usuarioActualPanel));
            frame.setVisible(true);
        });
        btnAdminEjercicios.addActionListener(e -> {
            Usuario usuarioActualPanel = sesionManager.obtenerUsuarioActual();
            if (usuarioActualPanel != null && usuarioActualPanel.isAdmin()) {
                JFrame frame = new JFrame("Administrar Ejercicios");
                frame.setSize(500, 400);
                frame.setLocationRelativeTo(this);
                frame.add(new PanelAdminEjercicios(ejercicioManager));
                frame.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Acceso solo para administradores.");
            }
        });
        btnAdminCategorias.addActionListener(e -> {
            Usuario usuarioActualPanel = sesionManager.obtenerUsuarioActual();
            if (usuarioActualPanel != null && usuarioActualPanel.isAdmin()) {
                JFrame frame = new JFrame("Administrar Categorías");
                frame.setSize(600, 300);
                frame.setLocationRelativeTo(this);
                frame.add(new PanelAdminCategorias(ejercicioManager));
                frame.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Acceso solo para administradores.");
            }
        });
        btnInfoGimnasio.addActionListener(e -> {
            JFrame frame = new JFrame("Información del Gimnasio");
            frame.setSize(400, 300);
            frame.setLocationRelativeTo(this);
            frame.add(new PanelInformacionGimnasio(infoManager));
            frame.setVisible(true);
        });
        btnSalir.addActionListener(e -> {
            System.exit(0);
        });
    }

    public static void main(String[] args) {
        try {
            // Instala FlatLaf Look & Feel (asegúrate de tener el JAR en el classpath)
            com.formdev.flatlaf.FlatLightLaf.install();
        } catch (Exception e) {
            System.out.println("No se pudo aplicar FlatLaf: " + e.getMessage());
        }
        SwingUtilities.invokeLater(() -> {
            new FidnessGUI().setVisible(true);
        });
    }
}
