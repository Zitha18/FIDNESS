import javax.swing.*;
import java.awt.*;

// Panel para mostrar la información del gimnasio
public class PanelInformacionGimnasio extends JPanel {
    public PanelInformacionGimnasio(InformacionGimnasioManager infoManager) {
        setLayout(new BorderLayout());
        JLabel lblTitulo = new JLabel("Información del Gimnasio");
        add(lblTitulo, BorderLayout.NORTH);
        
        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setText(infoManager.getInformacion().toString());
        add(new JScrollPane(area), BorderLayout.CENTER);
    }
}
