import modelo.Usuario;
import javax.swing.*;
import java.awt.*;
import java.util.List;

// Panel para mostrar preguntas y respuestas
public class PanelPreguntas extends JPanel {
    public PanelPreguntas(PreguntaManager preguntaManager, Usuario usuario) {
        setLayout(new BorderLayout());
        JLabel lblTitulo = new JLabel("Soporte: Preguntas y Respuestas");
        add(lblTitulo, BorderLayout.NORTH);

        DefaultListModel<String> modelo = new DefaultListModel<>();
        List<Pregunta> preguntas = preguntaManager.getPreguntas();
        for (int i = 0; i < preguntas.size(); i++) {
            modelo.addElement((i+1) + ". " + preguntas.get(i).toString());
        }
        JList<String> lista = new JList<>(modelo);
        JScrollPane scroll = new JScrollPane(lista);
        add(scroll, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        if (usuario != null) {
            if (usuario.isAdmin()) {
                JButton btnResponder = new JButton("Responder pregunta seleccionada");
                btnResponder.addActionListener(e -> {
                    int idx = lista.getSelectedIndex();
                    if (idx >= 0) {
                        String respuesta = JOptionPane.showInputDialog(this, "Respuesta para la pregunta:");
                        if (respuesta != null && !respuesta.trim().isEmpty()) {
                            preguntaManager.responderPregunta(idx, respuesta.trim());
                            modelo.set(idx, (idx+1) + ". " + preguntas.get(idx).toString());
                        }
                    }
                });
                panelBotones.add(btnResponder);
            }
            JButton btnPreguntar = new JButton("Hacer una pregunta");
            btnPreguntar.addActionListener(e -> {
                String pregunta = JOptionPane.showInputDialog(this, "Escribe tu pregunta:");
                if (pregunta != null && !pregunta.trim().isEmpty()) {
                    preguntaManager.agregarPregunta(new Pregunta(usuario.getNombre(), pregunta.trim(), null, "2025-08-25"));
                    modelo.addElement((modelo.size()+1) + ". " + preguntaManager.getPreguntas().get(modelo.size()).toString());
                }
            });
            panelBotones.add(btnPreguntar);
        }
        add(panelBotones, BorderLayout.SOUTH);
    }
}
