import javax.swing.*;
import java.awt.*;
import java.util.List;

// Panel de administración para editar y desactivar ejercicios
public class PanelAdminEjercicios extends JPanel {
    public PanelAdminEjercicios(EjercicioManager ejercicioManager) {
        setLayout(new BorderLayout());
        JLabel lblTitulo = new JLabel("Administrar Ejercicios");
        add(lblTitulo, BorderLayout.NORTH);

        DefaultListModel<Ejercicio> modelo = new DefaultListModel<>();
        List<Ejercicio> ejercicios = ejercicioManager.getListaEjercicios();
        for (Ejercicio e : ejercicios) {
            modelo.addElement(e);
        }
        JList<Ejercicio> lista = new JList<>(modelo);
        JScrollPane scroll = new JScrollPane(lista);
        add(scroll, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel(new FlowLayout());
        JButton btnEditar = new JButton("Editar");
        JButton btnAgregar = new JButton("Agregar Ejercicio");
        panelBotones.add(btnEditar);
        panelBotones.add(btnAgregar);
        add(panelBotones, BorderLayout.SOUTH);

        btnEditar.addActionListener(ev -> {
            Ejercicio seleccionado = lista.getSelectedValue();
            if (seleccionado != null) {
                JDialog dialogo = new JDialog((JFrame) SwingUtilities.getWindowAncestor(this), "Editar Ejercicio", true);
                dialogo.setSize(500, 500);
                dialogo.setLayout(new GridLayout(10, 2));
                JTextField txtNombre = new JTextField(seleccionado.getNombre());
                JTextField txtDesc = new JTextField(seleccionado.getDescripcion());
                JTextField txtVideo = new JTextField(seleccionado.getUrlVideo());
                JCheckBox chkActivo = new JCheckBox("Activo", seleccionado.isActivo());
                // Selección de grupos musculares
                JLabel lblGrupos = new JLabel("Grupos Musculares:");
                JList<String> listaGrupos = new JList<>(new DefaultListModel<>());
                DefaultListModel<String> modeloGrupos = (DefaultListModel<String>) listaGrupos.getModel();
                for (String cat : ejercicioManager.getCategoriasGrupos()) modeloGrupos.addElement(cat);
                listaGrupos.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
                for (String g : seleccionado.getGruposMusculares()) {
                    int idx = ejercicioManager.getCategoriasGrupos().indexOf(g);
                    if (idx >= 0) listaGrupos.addSelectionInterval(idx, idx);
                }
                // Selección de equipamiento
                JLabel lblEquip = new JLabel("Equipamiento:");
                JList<String> listaEquip = new JList<>(new DefaultListModel<>());
                DefaultListModel<String> modeloEquip = (DefaultListModel<String>) listaEquip.getModel();
                for (String cat : ejercicioManager.getCategoriasEquipamiento()) modeloEquip.addElement(cat);
                listaEquip.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
                for (String eq : seleccionado.getEquipamiento()) {
                    int idx = ejercicioManager.getCategoriasEquipamiento().indexOf(eq);
                    if (idx >= 0) listaEquip.addSelectionInterval(idx, idx);
                }
                dialogo.add(new JLabel("Nombre:")); dialogo.add(txtNombre);
                dialogo.add(new JLabel("Descripción:")); dialogo.add(txtDesc);
                dialogo.add(new JLabel("Video URL:")); dialogo.add(txtVideo);
                dialogo.add(new JLabel("Estado:")); dialogo.add(chkActivo);
                dialogo.add(lblGrupos); dialogo.add(new JScrollPane(listaGrupos));
                dialogo.add(lblEquip); dialogo.add(new JScrollPane(listaEquip));
                JButton btnGuardar = new JButton("Guardar");
                dialogo.add(btnGuardar); dialogo.add(new JLabel());
                btnGuardar.addActionListener(e -> {
                    seleccionado.setNombre(txtNombre.getText());
                    seleccionado.setDescripcion(txtDesc.getText());
                    seleccionado.setUrlVideo(txtVideo.getText());
                    seleccionado.setActivo(chkActivo.isSelected());
                    // Actualizar grupos musculares
                    List<String> nuevosGrupos = listaGrupos.getSelectedValuesList();
                    seleccionado.getGruposMusculares().clear();
                    seleccionado.getGruposMusculares().addAll(nuevosGrupos);
                    // Actualizar equipamiento
                    List<String> nuevoEquip = listaEquip.getSelectedValuesList();
                    seleccionado.getEquipamiento().clear();
                    seleccionado.getEquipamiento().addAll(nuevoEquip);
                    modelo.setElementAt(seleccionado, lista.getSelectedIndex());
                    // Guardar persistencia
                    ejercicioManager.guardarEjercicios();
                    dialogo.dispose();
                });
                dialogo.setLocationRelativeTo(this);
                dialogo.setVisible(true);
            }
        });

        btnAgregar.addActionListener(ev -> {
            JDialog dialogo = new JDialog((JFrame) SwingUtilities.getWindowAncestor(this), "Agregar Ejercicio", true);
            dialogo.setSize(500, 500);
            dialogo.setLayout(new GridLayout(10, 2));
            JTextField txtNombre = new JTextField();
            JTextField txtDesc = new JTextField();
            JTextField txtVideo = new JTextField();
            JCheckBox chkActivo = new JCheckBox("Activo", true);
            // Selección de grupos musculares
            JLabel lblGrupos = new JLabel("Grupos Musculares:");
            JList<String> listaGrupos = new JList<>(new DefaultListModel<>());
            DefaultListModel<String> modeloGrupos = (DefaultListModel<String>) listaGrupos.getModel();
            for (String cat : ejercicioManager.getCategoriasGrupos()) modeloGrupos.addElement(cat);
            listaGrupos.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
            // Selección de equipamiento
            JLabel lblEquip = new JLabel("Equipamiento:");
            JList<String> listaEquip = new JList<>(new DefaultListModel<>());
            DefaultListModel<String> modeloEquip = (DefaultListModel<String>) listaEquip.getModel();
            for (String cat : ejercicioManager.getCategoriasEquipamiento()) modeloEquip.addElement(cat);
            listaEquip.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
            dialogo.add(new JLabel("Nombre:")); dialogo.add(txtNombre);
            dialogo.add(new JLabel("Descripción:")); dialogo.add(txtDesc);
            dialogo.add(new JLabel("Video URL:")); dialogo.add(txtVideo);
            dialogo.add(new JLabel("Estado:")); dialogo.add(chkActivo);
            dialogo.add(lblGrupos); dialogo.add(new JScrollPane(listaGrupos));
            dialogo.add(lblEquip); dialogo.add(new JScrollPane(listaEquip));
            JButton btnGuardar = new JButton("Guardar");
            dialogo.add(btnGuardar); dialogo.add(new JLabel());
            btnGuardar.addActionListener(e -> {
                String nombre = txtNombre.getText().trim();
                String desc = txtDesc.getText().trim();
                String video = txtVideo.getText().trim();
                boolean activo = chkActivo.isSelected();
                List<String> grupos = listaGrupos.getSelectedValuesList();
                List<String> equip = listaEquip.getSelectedValuesList();
                if (!nombre.isEmpty()) {
                    Ejercicio nuevo = new Ejercicio(nombre, new java.util.ArrayList<>(grupos), new java.util.ArrayList<>(equip), desc);
                    nuevo.setUrlVideo(video);
                    nuevo.setActivo(activo);
                    ejercicioManager.getListaEjercicios().add(nuevo);
                    modelo.addElement(nuevo);
                    // Guardar persistencia
                    ejercicioManager.guardarEjercicios();
                    dialogo.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialogo, "El nombre es obligatorio.");
                }
            });
            dialogo.setLocationRelativeTo(this);
            dialogo.setVisible(true);
        });
    }
    }
// ...fin de la clase...
