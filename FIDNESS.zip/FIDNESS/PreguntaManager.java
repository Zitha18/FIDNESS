import java.util.ArrayList;
import java.util.List;
// Manager para preguntas y respuestas
public class PreguntaManager {
    private List<Pregunta> preguntas;

    public PreguntaManager() {
        preguntas = new ArrayList<>();
    }

    public void cargarPreguntas() {
        preguntas.clear();
        preguntas.add(new Pregunta("juan", "¿Cuál es el horario?", "Abrimos de 7 a 22hs", "2025-08-15"));
        preguntas.add(new Pregunta("maria", "¿Hay clases de yoga?", null, "2025-08-20"));
    }

    public void guardarPreguntas() {
        // Simula guardado
    }

    public List<Pregunta> getPreguntas() {
        return preguntas;
    }

    public void agregarPregunta(Pregunta pregunta) {
        preguntas.add(pregunta);
    }

    public void responderPregunta(int index, String respuesta) {
        if (index >= 0 && index < preguntas.size()) {
            preguntas.get(index).setRespuesta(respuesta);
        }
    }
}
