import javax.swing.*;
import java.awt.*;
import modelo.Usuario;

// Panel para mostrar el perfil
public class PerfilPanel extends JDialog {
    public PerfilPanel(JFrame parent, Usuario usuario) {
        super(parent, "Mi Perfil", true);
        setSize(300, 180);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(4, 1));

        JLabel lblNombre = new JLabel("Nombre: " + usuario.getNombre());
        JLabel lblApellido = new JLabel("Apellido: " + usuario.getApellido());
        JLabel lblCorreo = new JLabel("Correo: " + usuario.getCorreo());
        JButton btnCerrar = new JButton("Cerrar");

        add(lblNombre);
        add(lblApellido);
        add(lblCorreo);
        add(btnCerrar);

        btnCerrar.addActionListener(e -> dispose());
    }
}
