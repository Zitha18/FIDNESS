// Clase para anuncios del gimnasio
public class Anuncio {
    private String titulo;
    private String contenido;
    private String fecha;

    public Anuncio(String titulo, String contenido, String fecha) {
        this.titulo = titulo;
        this.contenido = contenido;
        this.fecha = fecha;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getContenido() {
        return contenido;
    }

    public String getFecha() {
        return fecha;
    }

    public String toString() {
        return titulo + " (" + fecha + ")\n" + contenido;
    }
}
