import javax.swing.*;
import modelo.Usuario;
import java.awt.*;
import java.awt.event.*;

// Panel para registrar usuarios nuevos
public class RegistroPanel extends JDialog {
    public RegistroPanel(JFrame parent, UsuarioManager usuarioManager) {
        super(parent, "Registrar Usuario", true);
        setSize(350, 250);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(6, 2));

        JLabel lblNombre = new JLabel("Nombre:");
        JTextField txtNombre = new JTextField();
        JLabel lblCorreo = new JLabel("Correo:");
        JTextField txtCorreo = new JTextField();
        JLabel lblPassword = new JLabel("Contraseña:");
        JPasswordField txtPassword = new JPasswordField();
        JCheckBox chkAdmin = new JCheckBox("Administrador");
        JButton btnRegistrar = new JButton("Registrar");
        JButton btnCancelar = new JButton("Cancelar");

        add(lblNombre); add(txtNombre);
        add(lblCorreo); add(txtCorreo);
        add(lblPassword); add(txtPassword);
        add(chkAdmin); add(new JLabel());
        add(btnRegistrar); add(btnCancelar);

        btnRegistrar.addActionListener(e -> {
            String nombre = txtNombre.getText().trim();
            String correo = txtCorreo.getText().trim();
            String password = new String(txtPassword.getPassword());
            boolean admin = chkAdmin.isSelected();
            if (nombre.isEmpty() || correo.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios");
                return;
            }
            Usuario nuevo = new Usuario(usuarioManager.obtenerNuevoId(), nombre, correo, password, admin);
            if (usuarioManager.registrarUsuario(nuevo)) {
                JOptionPane.showMessageDialog(this, "Usuario registrado correctamente");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "El correo ya está registrado");
            }
        });
        btnCancelar.addActionListener(e -> dispose());
    }
}
