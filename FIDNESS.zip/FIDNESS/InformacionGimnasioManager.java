// Manager para la información del gimnasio
public class InformacionGimnasioManager {
    private InformacionGimnasio info;

    public InformacionGimnasioManager() {
        cargarInformacion();
    }

    public void cargarInformacion() {
        // Simula carga de archivo
        info = new InformacionGimnasio(
            "Fidness Gym",
            "Av. Principal 1234",
            "1234-5678",
            "Lunes a Sábado 7-22hs",
            "El mejor gimnasio de la zona, con equipamiento moderno y clases para todos."
        );
    }

    public void guardarInformacion() {
        // Simula guardado
    }

    public InformacionGimnasio getInformacion() {
        return info;
    }

    public void setInformacion(InformacionGimnasio info) {
        this.info = info;
    }
}
