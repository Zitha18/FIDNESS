package persistencia;
// Clase para conexión a Derby
import java.sql.*;

public class ConexionDerby {
    public static Connection getConnection() throws SQLException {
    String url = "jdbc:derby://localhost:1527/bd/derby/fidnessDB;create=true";
    return DriverManager.getConnection(url);
    }
}
