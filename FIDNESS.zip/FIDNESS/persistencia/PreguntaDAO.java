package persistencia;
import java.sql.*;
import modelo.Pregunta;
import java.util.ArrayList;
import java.util.List;

public class PreguntaDAO {
    public void crearTabla() {
        try (Connection conn = ConexionDerby.getConnection();
             Statement stmt = conn.createStatement()) {
            String sql = "CREATE TABLE pregunta (id INT PRIMARY KEY, pregunta VARCHAR(255), respuesta VARCHAR(255))";
            stmt.executeUpdate(sql);
        } catch (SQLException e) {
            if (!"X0Y32".equals(e.getSQLState())) {
                e.printStackTrace();
            }
        }
    }
    public boolean agregarPregunta(Pregunta p) {
        String sql = "INSERT INTO pregunta (id, pregunta, respuesta) VALUES (?, ?, ?)";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, p.getId());
            ps.setString(2, p.getPregunta());
            ps.setString(3, p.getRespuesta());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public Pregunta obtenerPorId(int id) {
        String sql = "SELECT * FROM pregunta WHERE id = ?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Pregunta(
                    rs.getInt("id"),
                    rs.getString("pregunta"),
                    rs.getString("respuesta")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public List<Pregunta> obtenerTodas() {
        List<Pregunta> lista = new ArrayList<>();
        String sql = "SELECT * FROM pregunta";
        try (Connection conn = ConexionDerby.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Pregunta p = new Pregunta(
                    rs.getInt("id"),
                    rs.getString("pregunta"),
                    rs.getString("respuesta")
                );
                lista.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
    public boolean actualizarPregunta(Pregunta p) {
        String sql = "UPDATE pregunta SET pregunta=?, respuesta=? WHERE id=?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getPregunta());
            ps.setString(2, p.getRespuesta());
            ps.setInt(3, p.getId());
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean eliminarPregunta(int id) {
        String sql = "DELETE FROM pregunta WHERE id=?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
