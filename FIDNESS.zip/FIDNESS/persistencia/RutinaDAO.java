package persistencia;
import java.sql.*;
import modelo.Rutina;
import java.util.ArrayList;
import java.util.List;

public class RutinaDAO {
    public void crearTabla() {
        try (Connection conn = ConexionDerby.getConnection();
             Statement stmt = conn.createStatement()) {
            String sql = "CREATE TABLE rutina (id INT PRIMARY KEY, nombre VARCHAR(100), descripcion VARCHAR(255))";
            stmt.executeUpdate(sql);
        } catch (SQLException e) {
            if (!"X0Y32".equals(e.getSQLState())) {
                e.printStackTrace();
            }
        }
    }
    public boolean agregarRutina(Rutina r) {
        String sql = "INSERT INTO rutina (id, nombre, descripcion) VALUES (?, ?, ?)";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, r.getId());
            ps.setString(2, r.getNombre());
            ps.setString(3, r.getDescripcion());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public Rutina obtenerPorId(int id) {
        String sql = "SELECT * FROM rutina WHERE id = ?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Rutina(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("descripcion")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public List<Rutina> obtenerTodas() {
        List<Rutina> lista = new ArrayList<>();
        String sql = "SELECT * FROM rutina";
        try (Connection conn = ConexionDerby.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Rutina r = new Rutina(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("descripcion")
                );
                lista.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
    public boolean actualizarRutina(Rutina r) {
        String sql = "UPDATE rutina SET nombre=?, descripcion=? WHERE id=?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, r.getNombre());
            ps.setString(2, r.getDescripcion());
            ps.setInt(3, r.getId());
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean eliminarRutina(int id) {
        String sql = "DELETE FROM rutina WHERE id=?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
