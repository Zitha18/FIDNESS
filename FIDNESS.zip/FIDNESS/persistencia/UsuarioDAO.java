package persistencia;
// DAO para usuarios
import java.sql.*;
import modelo.Usuario;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {
    // Método para borrar la tabla usuario
    // Método main para debug: imprime todos los usuarios en Derby
    public static void main(String[] args) {
        if (args.length > 0) {
            if (args[0].equals("insertarUsuariosPrueba")) {
                UsuarioDAO dao = new UsuarioDAO();
                dao.insertarUsuariosPrueba();
                System.out.println("Usuarios de prueba insertados.");
                return;
            }
            if (args[0].equals("borrarTabla")) {
                UsuarioDAO dao = new UsuarioDAO();
                dao.borrarTabla();
                System.out.println("Tabla usuario borrada.");
                return;
            }
            if (args[0].equals("crearTabla")) {
                UsuarioDAO dao = new UsuarioDAO();
                dao.crearTabla();
                System.out.println("Tabla usuario creada.");
                return;
            }
            if (args[0].equals("insertarUsuario")) {
                UsuarioDAO dao = new UsuarioDAO();
                // insertarUsuario nombre correo password admin recordarme
                String nombre = args[1];
                String correo = args[2];
                String password = args[3];
                boolean admin = Boolean.parseBoolean(args[4]);
                boolean recordarme = args.length > 5 ? Boolean.parseBoolean(args[5]) : false;
                // Generar un id simple (puedes mejorar esto con autoincremento)
                int id = (int) (System.currentTimeMillis() % 100000);
                Usuario usuario = new Usuario(id, nombre, "", correo, password, admin, recordarme);
                boolean ok = false;
                try {
                    ok = dao.agregarUsuario(usuario);
                } catch (Throwable t) {
                    System.out.println("Error al insertar usuario:");
                    t.printStackTrace();
                }
                if (ok) {
                    System.out.println("Usuario insertado: " + nombre + " | " + correo);
                } else {
                    System.out.println("No se pudo insertar el usuario. Revisa si el id ya existe o si hay un error en la estructura de la tabla.");
                }
                return;
            }
        }
        UsuarioDAO dao = new UsuarioDAO();
        List<Usuario> usuarios = dao.obtenerTodos();
        System.out.println("Usuarios en Derby:");
        for (Usuario u : usuarios) {
            System.out.println(
                "id: " + u.getId() +
                " | nombre: " + u.getNombre() +
                " | apellido: " + u.getApellido() +
                " | correo: " + u.getCorreo() +
                " | password: " + u.getPassword() +
                " | admin: " + u.isAdmin() +
                " | recordarme: " + u.isRecordarme()
            );
        }
        if (usuarios.isEmpty()) {
            System.out.println("(No hay usuarios en la base de datos)");
        }
    }
    // Inserta varios usuarios de prueba en la base de datos
    // Este método ya está definido arriba, así que lo eliminamos para evitar duplicidad.
    // Autenticación de usuario por correo y password
    public Usuario loginUsuario(String correo, String password) {
        String sql = "SELECT * FROM usuario WHERE correo = ? AND password = ?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, correo);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Usuario(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("apellido"),
                    rs.getString("correo"),
                    rs.getString("password"),
                    rs.getBoolean("admin"),
                    rs.getBoolean("recordarme")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public void crearTabla() {
        try (Connection conn = ConexionDerby.getConnection();
             Statement stmt = conn.createStatement()) {
            String sql = "CREATE TABLE usuario (id INT PRIMARY KEY, nombre VARCHAR(100), apellido VARCHAR(100), correo VARCHAR(100), password VARCHAR(100), admin BOOLEAN, recordarme BOOLEAN)";
            stmt.executeUpdate(sql);
        } catch (SQLException e) {
            if (!"X0Y32".equals(e.getSQLState())) {
                e.printStackTrace();
            }
        }
    }

    // Agregar usuario
    public boolean agregarUsuario(Usuario u) {
        String sql = "INSERT INTO usuario (id, nombre, apellido, correo, password, admin, recordarme) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, u.getId());
            ps.setString(2, u.getNombre());
            ps.setString(3, u.getApellido());
            ps.setString(4, u.getCorreo());
            ps.setString(5, u.getPassword());
            ps.setBoolean(6, u.isAdmin());
            ps.setBoolean(7, u.isRecordarme());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Obtener usuario por id
    public Usuario obtenerPorId(int id) {
        String sql = "SELECT * FROM usuario WHERE id = ?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Usuario(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("apellido"),
                    rs.getString("correo"),
                    rs.getString("password"),
                    rs.getBoolean("admin"),
                    rs.getBoolean("recordarme")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Obtener todos los usuarios
    public List<Usuario> obtenerTodos() {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT * FROM usuario";
        try (Connection conn = ConexionDerby.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Usuario u = new Usuario(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("apellido"),
                    rs.getString("correo"),
                    rs.getString("password"),
                    rs.getBoolean("admin"),
                    rs.getBoolean("recordarme")
                );
                lista.add(u);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean actualizarUsuario(Usuario u) {
        String sql = "UPDATE usuario SET nombre=?, correo=?, password=?, admin=? WHERE id=?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, u.getNombre());
            ps.setString(2, u.getCorreo());
            ps.setString(3, u.getPassword());
            ps.setBoolean(4, u.isAdmin());
            ps.setInt(5, u.getId());
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Eliminar usuario
    public boolean eliminarUsuario(int id) {
        String sql = "DELETE FROM usuario WHERE id=?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public void borrarTabla() {
        try (Connection conn = ConexionDerby.getConnection();
             Statement stmt = conn.createStatement()) {
            String sql = "DROP TABLE usuario";
            stmt.executeUpdate(sql);
        } catch (SQLException e) {
            if (!"42Y55".equals(e.getSQLState())) { // Tabla no existe
                e.printStackTrace();
            }
        }
    }
    // Inserta varios usuarios de prueba en la base de datos
    public void insertarUsuariosPrueba() {
        agregarUsuario(new Usuario(1, "test", "", "test@mail.com", "12345", false, false));
        agregarUsuario(new Usuario(2, "admin", "", "admin@mail.com", "adminpass", true, false));
        agregarUsuario(new Usuario(3, "juan", "perez", "juan@mail.com", "juanpass", false, true));
        agregarUsuario(new Usuario(4, "ana", "lopez", "ana@mail.com", "anapass", false, false));
    }
}
