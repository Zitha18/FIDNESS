package persistencia;
import java.sql.*;
import modelo.Historial;
import java.util.ArrayList;
import java.util.List;

public class HistorialDAO {
    public void crearTabla() {
        try (Connection conn = ConexionDerby.getConnection();
             Statement stmt = conn.createStatement()) {
            String sql = "CREATE TABLE historial (id INT PRIMARY KEY, usuarioId INT, ejercicioId INT, fecha DATE, repeticiones INT)";
            stmt.executeUpdate(sql);
        } catch (SQLException e) {
            if (!"X0Y32".equals(e.getSQLState())) {
                e.printStackTrace();
            }
        }
    }
    public boolean agregarHistorial(Historial h) {
        String sql = "INSERT INTO historial (id, usuarioId, ejercicioId, fecha, repeticiones) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, h.getId());
            ps.setInt(2, h.getUsuarioId());
            ps.setInt(3, h.getEjercicioId());
            ps.setDate(4, h.getFecha());
            ps.setInt(5, h.getRepeticiones());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public Historial obtenerPorId(int id) {
        String sql = "SELECT * FROM historial WHERE id = ?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Historial(
                    rs.getInt("id"),
                    rs.getInt("usuarioId"),
                    rs.getInt("ejercicioId"),
                    rs.getDate("fecha"),
                    rs.getInt("repeticiones")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public List<Historial> obtenerTodos() {
        List<Historial> lista = new ArrayList<>();
        String sql = "SELECT * FROM historial";
        try (Connection conn = ConexionDerby.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Historial h = new Historial(
                    rs.getInt("id"),
                    rs.getInt("usuarioId"),
                    rs.getInt("ejercicioId"),
                    rs.getDate("fecha"),
                    rs.getInt("repeticiones")
                );
                lista.add(h);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
    public boolean actualizarHistorial(Historial h) {
        String sql = "UPDATE historial SET usuarioId=?, ejercicioId=?, fecha=?, repeticiones=? WHERE id=?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, h.getUsuarioId());
            ps.setInt(2, h.getEjercicioId());
            ps.setDate(3, h.getFecha());
            ps.setInt(4, h.getRepeticiones());
            ps.setInt(5, h.getId());
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean eliminarHistorial(int id) {
        String sql = "DELETE FROM historial WHERE id=?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
