package persistencia;
// DAO para ejercicios
import java.sql.*;
import modelo.Ejercicio;

public class EjercicioDAO {
    public void crearTabla() {
        try (Connection conn = ConexionDerby.getConnection();
             Statement stmt = conn.createStatement()) {
            String sql = "CREATE TABLE ejercicio (id INT PRIMARY KEY, nombre VARCHAR(100), categoria VARCHAR(50), activo BOOLEAN)";
            stmt.executeUpdate(sql);
        } catch (SQLException e) {
            // Si la tabla ya existe, ignora el error
            if (!e.getSQLState().equals("X0Y32")) {
                e.printStackTrace();
            }
        }
    }
        // Método para agregar un ejercicio
        public boolean agregarEjercicio(Ejercicio ej) {
            String sql = "INSERT INTO ejercicio (id, nombre, categoria, activo) VALUES (?, ?, ?, ?)";
            try (Connection conn = ConexionDerby.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, ej.getId());
                ps.setString(2, ej.getNombre());
                ps.setString(3, ej.getCategoria());
                ps.setBoolean(4, ej.isActivo());
                ps.executeUpdate();
                return true;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }

        // Método para obtener un ejercicio por id
        public Ejercicio obtenerPorId(int id) {
            String sql = "SELECT * FROM ejercicio WHERE id = ?";
            try (Connection conn = ConexionDerby.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return new Ejercicio(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("categoria"),
                        rs.getBoolean("activo")
                    );
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return null;
        }

        // Método para obtener todos los ejercicios
        public java.util.List<Ejercicio> obtenerTodos() {
            java.util.List<Ejercicio> lista = new java.util.ArrayList<>();
            String sql = "SELECT * FROM ejercicio";
            try (Connection conn = ConexionDerby.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    Ejercicio ej = new Ejercicio(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("categoria"),
                        rs.getBoolean("activo")
                    );
                    lista.add(ej);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return lista;
        }

        // Método para actualizar un ejercicio
        public boolean actualizarEjercicio(Ejercicio ej) {
            String sql = "UPDATE ejercicio SET nombre=?, categoria=?, activo=? WHERE id=?";
            try (Connection conn = ConexionDerby.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, ej.getNombre());
                ps.setString(2, ej.getCategoria());
                ps.setBoolean(3, ej.isActivo());
                ps.setInt(4, ej.getId());
                int filas = ps.executeUpdate();
                return filas > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }

        // Método para eliminar un ejercicio
        public boolean eliminarEjercicio(int id) {
            String sql = "DELETE FROM ejercicio WHERE id=?";
            try (Connection conn = ConexionDerby.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, id);
                int filas = ps.executeUpdate();
                return filas > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }
}
