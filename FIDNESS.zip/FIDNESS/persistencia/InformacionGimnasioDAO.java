package persistencia;
import java.sql.*;
import modelo.InformacionGimnasio;
import java.util.ArrayList;
import java.util.List;

public class InformacionGimnasioDAO {
    public void crearTabla() {
        try (Connection conn = ConexionDerby.getConnection();
             Statement stmt = conn.createStatement()) {
            String sql = "CREATE TABLE informacion_gimnasio (id INT PRIMARY KEY, nombre VARCHAR(100), direccion VARCHAR(255), telefono VARCHAR(50), horario VARCHAR(100))";
            stmt.executeUpdate(sql);
        } catch (SQLException e) {
            if (!"X0Y32".equals(e.getSQLState())) {
                e.printStackTrace();
            }
        }
    }
    public boolean agregarInformacion(InformacionGimnasio info) {
        String sql = "INSERT INTO informacion_gimnasio (id, nombre, direccion, telefono, horario) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, info.getId());
            ps.setString(2, info.getNombre());
            ps.setString(3, info.getDireccion());
            ps.setString(4, info.getTelefono());
            ps.setString(5, info.getHorario());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public InformacionGimnasio obtenerPorId(int id) {
        String sql = "SELECT * FROM informacion_gimnasio WHERE id = ?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new InformacionGimnasio(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("direccion"),
                    rs.getString("telefono"),
                    rs.getString("horario")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public List<InformacionGimnasio> obtenerTodas() {
        List<InformacionGimnasio> lista = new ArrayList<>();
        String sql = "SELECT * FROM informacion_gimnasio";
        try (Connection conn = ConexionDerby.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                InformacionGimnasio info = new InformacionGimnasio(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("direccion"),
                    rs.getString("telefono"),
                    rs.getString("horario")
                );
                lista.add(info);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
    public boolean actualizarInformacion(InformacionGimnasio info) {
        String sql = "UPDATE informacion_gimnasio SET nombre=?, direccion=?, telefono=?, horario=? WHERE id=?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, info.getNombre());
            ps.setString(2, info.getDireccion());
            ps.setString(3, info.getTelefono());
            ps.setString(4, info.getHorario());
            ps.setInt(5, info.getId());
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean eliminarInformacion(int id) {
        String sql = "DELETE FROM informacion_gimnasio WHERE id=?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
