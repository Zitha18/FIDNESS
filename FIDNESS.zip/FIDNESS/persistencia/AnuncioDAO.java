package persistencia;
import java.sql.*;
import modelo.Anuncio;
import java.util.ArrayList;
import java.util.List;

public class AnuncioDAO {
    public void crearTabla() {
        try (Connection conn = ConexionDerby.getConnection();
             Statement stmt = conn.createStatement()) {
            String sql = "CREATE TABLE anuncio (id INT PRIMARY KEY, titulo VARCHAR(100), mensaje VARCHAR(255))";
            stmt.executeUpdate(sql);
        } catch (SQLException e) {
            if (!"X0Y32".equals(e.getSQLState())) {
                e.printStackTrace();
            }
        }
    }
    public boolean agregarAnuncio(Anuncio a) {
        String sql = "INSERT INTO anuncio (id, titulo, mensaje) VALUES (?, ?, ?)";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, a.getId());
            ps.setString(2, a.getTitulo());
            ps.setString(3, a.getMensaje());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public Anuncio obtenerPorId(int id) {
        String sql = "SELECT * FROM anuncio WHERE id = ?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Anuncio(
                    rs.getInt("id"),
                    rs.getString("titulo"),
                    rs.getString("mensaje")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public List<Anuncio> obtenerTodos() {
        List<Anuncio> lista = new ArrayList<>();
        String sql = "SELECT * FROM anuncio";
        try (Connection conn = ConexionDerby.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Anuncio a = new Anuncio(
                    rs.getInt("id"),
                    rs.getString("titulo"),
                    rs.getString("mensaje")
                );
                lista.add(a);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
    public boolean actualizarAnuncio(Anuncio a) {
        String sql = "UPDATE anuncio SET titulo=?, mensaje=? WHERE id=?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, a.getTitulo());
            ps.setString(2, a.getMensaje());
            ps.setInt(3, a.getId());
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean eliminarAnuncio(int id) {
        String sql = "DELETE FROM anuncio WHERE id=?";
        try (Connection conn = ConexionDerby.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
