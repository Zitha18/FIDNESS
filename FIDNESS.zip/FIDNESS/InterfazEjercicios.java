import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// GUI para explorar ejercicios
public class InterfazEjercicios extends JFrame {
    private EjercicioManager ejercicioManager;

    private boolean soloFavoritosInicial;

    public InterfazEjercicios(EjercicioManager ejercicioManager) {
        this(ejercicioManager, false);
    }

    public InterfazEjercicios(EjercicioManager ejercicioManager, boolean soloFavoritosInicial) {
        this.ejercicioManager = ejercicioManager;
        this.soloFavoritosInicial = soloFavoritosInicial;
        setTitle("Catálogo de Ejercicios");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Panel superior: búsqueda y filtros
        JPanel panelSuperior = new JPanel(new FlowLayout());
        JTextField txtBuscar = new JTextField(20);
        JButton btnBuscar = new JButton("Buscar");
        JComboBox<String> comboGrupo = new JComboBox<>(new String[]{"Todos", "Piernas", "Glúteos", "Bíceps", "Tríceps", "Pecho", "Dorsales"});
            // Se elimina el filtro por equipamiento
    JCheckBox chkFavoritos = new JCheckBox("Solo favoritos", soloFavoritosInicial);
    JButton btnVerFavoritos = new JButton("Ver Favoritos");
    panelSuperior.add(new JLabel("Buscar por nombre:"));
    panelSuperior.add(txtBuscar);
    panelSuperior.add(btnBuscar);
    panelSuperior.add(new JLabel("Grupo muscular:"));
    panelSuperior.add(comboGrupo);
            // Se elimina el filtrado por equipamiento
    panelSuperior.add(chkFavoritos);
    panelSuperior.add(btnVerFavoritos);
    add(panelSuperior, BorderLayout.NORTH);

        // Lista de ejercicios
        DefaultListModel<Ejercicio> modeloLista = new DefaultListModel<>();
        JList<Ejercicio> listaEjercicios = new JList<>(modeloLista);
        listaEjercicios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(listaEjercicios);
        add(scroll, BorderLayout.CENTER);

        // Botón para ver detalle
        JButton btnDetalle = new JButton("Ver Detalle");
        add(btnDetalle, BorderLayout.SOUTH);

        // Método para actualizar la lista según filtros
        Runnable actualizarLista = () -> {
            modeloLista.clear();
            List<Ejercicio> ejercicios = new ArrayList<>();
            for (Ejercicio e : ejercicioManager.getListaEjercicios()) {
                if (e.isActivo()) ejercicios.add(e);
            }
            String nombre = txtBuscar.getText().trim();
            String grupo = (String) comboGrupo.getSelectedItem();
            boolean soloFav = chkFavoritos.isSelected();
            // Filtrado por nombre
            if (!nombre.isEmpty()) {
                ejercicios = ejercicioManager.buscarPorNombre(nombre);
                // Solo mostrar activos
                ejercicios.removeIf(e -> !e.isActivo());
            }
            // Filtrado por grupo muscular
            if (grupo != null && !grupo.equals("Todos")) {
                List<Ejercicio> filtrados = new ArrayList<>();
                for (Ejercicio e : ejercicios) {
                    if (e.getGruposMusculares().contains(grupo)) filtrados.add(e);
                }
                ejercicios = filtrados;
            }
            // Solo favoritos
            if (soloFav) {
                List<Ejercicio> favs = new ArrayList<>();
                for (Ejercicio e : ejercicios) if (e.isFavorito()) favs.add(e);
                ejercicios = favs;
            }
            for (Ejercicio e : ejercicios) modeloLista.addElement(e);
        };

        // Botón para ver solo favoritos
        btnVerFavoritos.addActionListener(ev -> {
            modeloLista.clear();
            List<Ejercicio> favs = ejercicioManager.obtenerFavoritos();
            for (Ejercicio e : favs) modeloLista.addElement(e);
        });

        // Listeners para filtros
        btnBuscar.addActionListener(e -> actualizarLista.run());
        comboGrupo.addActionListener(e -> actualizarLista.run());
            // Se elimina el listener de comboEquip
        chkFavoritos.addActionListener(e -> actualizarLista.run());

        // Mostrar detalle y marcar favorito
        btnDetalle.addActionListener(e -> {
            Ejercicio seleccionado = listaEjercicios.getSelectedValue();
            if (seleccionado != null) {
                JDialog detalle = new JDialog(this, "Detalle de Ejercicio", true);
                detalle.setSize(400, 350);
                detalle.setLayout(new GridLayout(8, 1));
                detalle.add(new JLabel("Nombre: " + seleccionado.getNombre()));
                detalle.add(new JLabel("Grupos: " + String.join(", ", seleccionado.getGruposMusculares())));
                detalle.add(new JLabel("Equipamiento: " + String.join(", ", seleccionado.getEquipamiento())));
                detalle.add(new JLabel("Descripción: " + seleccionado.getDescripcion()));
                detalle.add(new JLabel("Consejos: " + String.join(", ", seleccionado.getConsejos())));
                detalle.add(new JLabel("Errores Comunes: " + String.join(", ", seleccionado.getErroresComunes())));
                JCheckBox chkFav = new JCheckBox("Favorito", seleccionado.isFavorito());
                detalle.add(chkFav);
                JButton btnCerrar = new JButton("Cerrar");
                detalle.add(btnCerrar);
                chkFav.addActionListener(ev -> {
                    ejercicioManager.marcarFavorito(seleccionado, chkFav.isSelected());
                    actualizarLista.run();
                });
                btnCerrar.addActionListener(ev -> detalle.dispose());
                detalle.setLocationRelativeTo(this);
                detalle.setVisible(true);
            }
        });

        // Inicializar lista
    actualizarLista.run();
    }
}
