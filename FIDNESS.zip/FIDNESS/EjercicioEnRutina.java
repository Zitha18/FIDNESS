// Clase para representar un ejercicio dentro de una rutina, con nota
public class EjercicioEnRutina {
    private Ejercicio ejercicio;
    private String nota;

    public EjercicioEnRutina(Ejercicio ejercicio, String nota) {
        this.ejercicio = ejercicio;
        this.nota = nota;
    }
    public Ejercicio getEjercicio() { return ejercicio; }
    public String getNota() { return nota; }
    public void setNota(String nota) { this.nota = nota; }
    public String toString() {
        return ejercicio.getNombre() + (nota != null && !nota.isEmpty() ? " (Nota: " + nota + ")" : "");
    }
}
