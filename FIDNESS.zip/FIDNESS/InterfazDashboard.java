import javax.swing.*;
import java.awt.*;

// Panel resumen semanal de actividad
public class InterfazDashboard extends JPanel {
    public InterfazDashboard(HistorialManager historialManager) {
        setLayout(new GridLayout(3, 1));
        JLabel lblEntrenamientos = new JLabel("Entrenamientos esta semana: " + historialManager.getEntrenamientosSemana());
        JLabel lblSeries = new JLabel("Total de series esta semana: " + historialManager.getTotalSeriesSemana());
        JLabel lblEjercicios = new JLabel("Total de ejercicios hechos esta semana: " + getTotalEjerciciosSemana(historialManager));
        add(lblEntrenamientos);
        add(lblSeries);
        add(lblEjercicios);

    }

    private int getTotalEjerciciosSemana(HistorialManager historialManager) {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        int semana = cal.get(java.util.Calendar.WEEK_OF_YEAR);
        int año = cal.get(java.util.Calendar.YEAR);
        int total = 0;
        for (RegistroEntrenamiento r : historialManager.getHistorialCompleto()) {
            cal.setTime(r.getFecha());
            if (cal.get(java.util.Calendar.WEEK_OF_YEAR) == semana && cal.get(java.util.Calendar.YEAR) == año) {
                total += r.getEjerciciosRealizados().size();
            }
        }
        return total;
    }
}
