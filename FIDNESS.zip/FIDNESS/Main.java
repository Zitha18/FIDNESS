// Punto de entrada de la aplicación Fidness
public class Main {
    public static void main(String[] args) {
        UsuarioManager usuarioManager = new UsuarioManager();
        SesionManager sesionManager = new SesionManager();
        InterfazLogin interfazLogin = new InterfazLogin(usuarioManager, sesionManager);
        InterfazPerfil interfazPerfil = new InterfazPerfil();
        java.util.Scanner sc = new java.util.Scanner(System.in);
        int opcion = 0;
        do {
            System.out.println("\n--- Bienvenido a Fidness ---");
            System.out.println("1. Iniciar Sesión");
            System.out.println("2. Recordar Sesión");
            System.out.println("3. Recuperar Contraseña");
            System.out.println("4. Ver Perfil");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            try {
                opcion = Integer.parseInt(sc.nextLine());
            } catch (Exception e) {
                opcion = 0;
            }
            switch(opcion) {
                case 1:
                    interfazLogin.mostrarLogin();
                    break;
                case 2:
                    interfazLogin.mostrarRecordarSesion();
                    break;
                case 3:
                    interfazLogin.mostrarRecuperarPassword();
                    break;
                case 4:
                    if (sesionManager.sesionActiva()) {
                        interfazPerfil.mostrarPerfil(sesionManager.obtenerUsuarioActual());
                    } else {
                        System.out.println("Debe iniciar sesión primero.");
                    }
                    break;
                case 5:
                    System.out.println("Saliendo de Fidness...");
                    break;
                default:
                    System.out.println("Opción inválida");
            }
        } while(opcion != 5);
        sc.close();
    }
}
