package red;
// DTO para peticiones
import java.io.Serializable;

public class Request implements Serializable {
    public String accion;
    public Object datos;
    public Request(String accion, Object datos) {
        this.accion = accion;
        this.datos = datos;
    }
}
