package red;
// DTO para respuestas
import java.io.Serializable;

public class Response implements Serializable {
    public boolean exito;
    public Object datos;
    public String mensaje;
    public Response(boolean exito, Object datos, String mensaje) {
        this.exito = exito;
        this.datos = datos;
        this.mensaje = mensaje;
    }
}
