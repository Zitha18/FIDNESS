// Clase para preguntas y respuestas de soporte
public class Pregunta {
    private String usuario;
    private String pregunta;
    private String respuesta;
    private String fecha;

    public Pregunta(String usuario, String pregunta, String respuesta, String fecha) {
        this.usuario = usuario;
        this.pregunta = pregunta;
        this.respuesta = respuesta;
        this.fecha = fecha;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getPregunta() {
        return pregunta;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }

    public String getFecha() {
        return fecha;
    }

    public String toString() {
        return usuario + " preguntó: " + pregunta + "\nRespuesta: " + (respuesta == null ? "(sin responder)" : respuesta);
    }
}
