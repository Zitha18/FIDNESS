import java.util.*;
import java.io.*;

// Gestión del historial de entrenamientos
public class HistorialManager {
    private List<RegistroEntrenamiento> historial;

    public HistorialManager() {
        historial = new ArrayList<>();
        cargarHistorial();
    }
    public void agregarRegistro(RegistroEntrenamiento registro) {
        historial.add(registro);
        guardarHistorial();
    }
    public List<RegistroEntrenamiento> getHistorialPorFecha(Date fecha) {
        List<RegistroEntrenamiento> res = new ArrayList<>();
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        for (RegistroEntrenamiento r : historial) {
            cal1.setTime(r.getFecha());
            cal2.setTime(fecha);
            if (cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) && cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)) {
                res.add(r);
            }
        }
        return res;
    }
    public List<SerieEjercicio> getProgresoPorEjercicio(String nombreEjercicio) {
        List<SerieEjercicio> progreso = new ArrayList<>();
        for (RegistroEntrenamiento r : historial) {
            for (EjercicioRealizado er : r.getEjerciciosRealizados()) {
                if (er.getNombreEjercicio().equals(nombreEjercicio)) {
                    progreso.addAll(er.getSeries());
                }
            }
        }
        return progreso;
    }
    public int getEntrenamientosSemana() {
        Calendar cal = Calendar.getInstance();
        int semana = cal.get(Calendar.WEEK_OF_YEAR);
        int año = cal.get(Calendar.YEAR);
        int count = 0;
        for (RegistroEntrenamiento r : historial) {
            cal.setTime(r.getFecha());
            if (cal.get(Calendar.WEEK_OF_YEAR) == semana && cal.get(Calendar.YEAR) == año) count++;
        }
        return count;
    }
    public int getTotalSeriesSemana() {
        Calendar cal = Calendar.getInstance();
        int semana = cal.get(Calendar.WEEK_OF_YEAR);
        int año = cal.get(Calendar.YEAR);
        int total = 0;
        for (RegistroEntrenamiento r : historial) {
            cal.setTime(r.getFecha());
            if (cal.get(Calendar.WEEK_OF_YEAR) == semana && cal.get(Calendar.YEAR) == año) {
                for (EjercicioRealizado er : r.getEjerciciosRealizados()) {
                    total += er.getSeries().size();
                }
            }
        }
        return total;
    }
    public double getTotalPesoSemana() {
        Calendar cal = Calendar.getInstance();
        int semana = cal.get(Calendar.WEEK_OF_YEAR);
        int año = cal.get(Calendar.YEAR);
        double total = 0;
        for (RegistroEntrenamiento r : historial) {
            cal.setTime(r.getFecha());
            if (cal.get(Calendar.WEEK_OF_YEAR) == semana && cal.get(Calendar.YEAR) == año) {
                for (EjercicioRealizado er : r.getEjerciciosRealizados()) {
                    for (SerieEjercicio s : er.getSeries()) {
                        total += s.getPeso();
                    }
                }
            }
        }
        return total;
    }
    public boolean guardarHistorial() {
        try {
            FileWriter fw = new FileWriter("historial.txt");
            for (RegistroEntrenamiento r : historial) {
                fw.write(r.getFecha().getTime() + ";" + r.getNombreRutina() + ";");
                for (EjercicioRealizado er : r.getEjerciciosRealizados()) {
                    fw.write(er.getNombreEjercicio() + "|");
                    for (SerieEjercicio s : er.getSeries()) {
                        fw.write(s.getNumeroSerie() + "," + s.getRepeticiones() + "," + s.getPeso() + "|");
                    }
                    fw.write("#");
                }
                fw.write("\n");
            }
            fw.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }
    public boolean cargarHistorial() {
        historial.clear();
        try {
            File f = new File("historial.txt");
            if (!f.exists()) return false;
            Scanner sc = new Scanner(f);
            while (sc.hasNextLine()) {
                String linea = sc.nextLine();
                String[] partes = linea.split(";");
                if (partes.length >= 2) {
                    Date fecha = new Date(Long.parseLong(partes[0]));
                    String nombreRutina = partes[1];
                    RegistroEntrenamiento r = new RegistroEntrenamiento(fecha, nombreRutina);
                    if (partes.length > 2) {
                        String[] ejercicios = partes[2].split("#");
                        for (String ej : ejercicios) {
                            if (!ej.trim().isEmpty()) {
                                String[] datosEj = ej.split("\\|");
                                if (datosEj.length > 0) {
                                    EjercicioRealizado er = new EjercicioRealizado(datosEj[0]);
                                    for (int i = 1; i < datosEj.length; i++) {
                                        String[] serieDatos = datosEj[i].split(",");
                                        if (serieDatos.length == 3) {
                                            int num = Integer.parseInt(serieDatos[0]);
                                            int reps = Integer.parseInt(serieDatos[1]);
                                            double peso = Double.parseDouble(serieDatos[2]);
                                            er.agregarSerie(new SerieEjercicio(num, reps, peso));
                                        }
                                    }
                                    r.agregarEjercicioRealizado(er);
                                }
                            }
                        }
                    }
                    historial.add(r);
                }
            }
            sc.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }
    public List<RegistroEntrenamiento> getHistorialCompleto() {
        return historial;
    }
}
