import java.util.*;

// Modelo de ejercicio
public class Ejercicio {
    private String nombre;
    private List<String> gruposMusculares;
    private List<String> equipamiento;
    private String descripcion;
    private List<String> consejos;
    private List<String> erroresComunes;
    private boolean favorito;
    private String urlVideo;
    private boolean activo;

    public Ejercicio(String nombre, List<String> gruposMusculares, List<String> equipamiento, String descripcion) {
        this.nombre = nombre;
        this.gruposMusculares = gruposMusculares;
        this.equipamiento = equipamiento;
        this.descripcion = descripcion;
        this.consejos = new ArrayList<>();
        this.erroresComunes = new ArrayList<>();
        this.favorito = false;
        this.urlVideo = "";
        this.activo = true;
    }
    public String getUrlVideo() { return urlVideo; }
    public void setUrlVideo(String urlVideo) { this.urlVideo = urlVideo; }
    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getNombre() { return nombre; }
    public List<String> getGruposMusculares() { return gruposMusculares; }
    public List<String> getEquipamiento() { return equipamiento; }
    public String getDescripcion() { return descripcion; }
    public List<String> getConsejos() { return consejos; }
    public List<String> getErroresComunes() { return erroresComunes; }
    public boolean isFavorito() { return favorito; }
    public void setFavorito(boolean favorito) { this.favorito = favorito; }
    public void setConsejos(List<String> consejos) { this.consejos = consejos; }
    public void setErroresComunes(List<String> erroresComunes) { this.erroresComunes = erroresComunes; }
    public String toString() {
        return nombre + " (" + String.join("/", gruposMusculares) + ")";
    }
}
