import java.util.*;
import java.io.*;

// Gestión de ejercicios
public class EjercicioManager {
    private List<Ejercicio> listaEjercicios;
    private List<String> categoriasGrupos;
    private List<String> categoriasEquipamiento;

    public EjercicioManager() {
        listaEjercicios = new ArrayList<>();
        categoriasGrupos = new ArrayList<>();
        categoriasEquipamiento = new ArrayList<>();
        cargarEjercicios();
        cargarCategorias();
    }
    public List<String> getCategoriasGrupos() { return categoriasGrupos; }
    public List<String> getCategoriasEquipamiento() { return categoriasEquipamiento; }
    public void agregarCategoriaGrupo(String nombre) { if (!categoriasGrupos.contains(nombre)) categoriasGrupos.add(nombre); }
    public void renombrarCategoriaGrupo(String viejo, String nuevo) {
        int idx = categoriasGrupos.indexOf(viejo);
        if (idx >= 0) categoriasGrupos.set(idx, nuevo);
    }
    public void eliminarCategoriaGrupo(String nombre) { categoriasGrupos.remove(nombre); }
    public void agregarCategoriaEquipamiento(String nombre) { if (!categoriasEquipamiento.contains(nombre)) categoriasEquipamiento.add(nombre); }
    public void renombrarCategoriaEquipamiento(String viejo, String nuevo) {
        int idx = categoriasEquipamiento.indexOf(viejo);
        if (idx >= 0) categoriasEquipamiento.set(idx, nuevo);
    }
    public void eliminarCategoriaEquipamiento(String nombre) { categoriasEquipamiento.remove(nombre); }
    public void cargarCategorias() {
        categoriasGrupos.clear();
        categoriasEquipamiento.clear();
        categoriasGrupos.add("Piernas");
        categoriasGrupos.add("Glúteos");
        categoriasGrupos.add("Bíceps");
        categoriasGrupos.add("Tríceps");
        categoriasGrupos.add("Pecho");
        categoriasGrupos.add("Dorsales");
        categoriasEquipamiento.add("Mancuernas");
        categoriasEquipamiento.add("Barra");
        categoriasEquipamiento.add("Peso corporal");
        categoriasEquipamiento.add("Banco");
    }

    public List<Ejercicio> buscarPorNombre(String nombre) {
        List<Ejercicio> res = new ArrayList<>();
        for (Ejercicio e : listaEjercicios) {
            if (e.getNombre().toLowerCase().contains(nombre.toLowerCase())) {
                res.add(e);
            }
        }
        return res;
    }

    public List<Ejercicio> filtrarPorGrupoMuscular(List<String> grupos) {
        List<Ejercicio> res = new ArrayList<>();
        for (Ejercicio e : listaEjercicios) {
            for (String g : grupos) {
                if (e.getGruposMusculares().contains(g)) {
                    res.add(e);
                    break;
                }
            }
        }
        return res;
    }

    public List<Ejercicio> filtrarPorEquipamiento(List<String> equipamientos) {
        List<Ejercicio> res = new ArrayList<>();
        for (Ejercicio e : listaEjercicios) {
            for (String eq : equipamientos) {
                if (e.getEquipamiento().contains(eq)) {
                    res.add(e);
                    break;
                }
            }
        }
        return res;
    }

    public void marcarFavorito(Ejercicio ejercicio, boolean favorito) {
        ejercicio.setFavorito(favorito);
        guardarEjercicios();
    }

    public List<Ejercicio> obtenerFavoritos() {
        List<Ejercicio> favs = new ArrayList<>();
        for (Ejercicio e : listaEjercicios) {
            if (e.isFavorito()) favs.add(e);
        }
        return favs;
    }

    public Ejercicio buscarPorNombreExacto(String nombre) {
        for (Ejercicio e : listaEjercicios) {
            if (e.getNombre().equalsIgnoreCase(nombre)) return e;
        }
        return null;
    }

    public boolean guardarEjercicios() {
        try {
            FileWriter fw = new FileWriter("ejercicios.txt");
            for (Ejercicio e : listaEjercicios) {
                fw.write(e.getNombre() + "," + String.join("|", e.getGruposMusculares()) + "," + String.join("|", e.getEquipamiento()) + "," + e.getDescripcion().replace(",", ";") + "," + String.join("|", e.getConsejos()) + "," + String.join("|", e.getErroresComunes()) + "," + (e.isFavorito() ? "1" : "0") + "\n");
            }
            fw.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public boolean cargarEjercicios() {
        listaEjercicios.clear();
        try {
            File f = new File("ejercicios.txt");
            if (!f.exists()) return false;
            Scanner sc = new Scanner(f);
            while (sc.hasNextLine()) {
                String[] datos = sc.nextLine().split(",");
                if (datos.length >= 7) {
                    List<String> grupos = Arrays.asList(datos[1].split("\\|"));
                    List<String> equip = Arrays.asList(datos[2].split("\\|"));
                    Ejercicio ej = new Ejercicio(datos[0], grupos, equip, datos[3]);
                    ej.setConsejos(Arrays.asList(datos[4].split("\\|")));
                    ej.setErroresComunes(Arrays.asList(datos[5].split("\\|")));
                    ej.setFavorito("1".equals(datos[6]));
                    listaEjercicios.add(ej);
                }
            }
            sc.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public List<Ejercicio> getListaEjercicios() {
        return listaEjercicios;
    }
}
