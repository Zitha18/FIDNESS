import modelo.Usuario;
// Clase para manejar la sesión del usuario
public class SesionManager {
    private Usuario usuarioActual;

    public void iniciarSesion(Usuario usuario, boolean recordarme) {
        usuarioActual = usuario;
        usuario.setRecordarme(recordarme);
    }

    public void cerrarSesion() {
        usuarioActual = null;
    }

    public Usuario obtenerUsuarioActual() {
        return usuarioActual;
    }

    public boolean sesionActiva() {
        return usuarioActual != null;
    }
}
