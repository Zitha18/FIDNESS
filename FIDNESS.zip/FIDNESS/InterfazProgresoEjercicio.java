import javax.swing.*;
import java.awt.*;
import java.util.List;

// GUI para mostrar progreso de un ejercicio
public class InterfazProgresoEjercicio extends JFrame {
    public InterfazProgresoEjercicio(HistorialManager historialManager, String nombreEjercicio) {
        setTitle("Progreso: " + nombreEjercicio);
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        List<SerieEjercicio> progreso = historialManager.getProgresoPorEjercicio(nombreEjercicio);
        JPanel panelGrafico = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                int ancho = getWidth();
                int alto = getHeight();
                int margen = 40;
                int n = progreso.size();
                if (n == 0) return;
                double maxPeso = progreso.stream().mapToDouble(SerieEjercicio::getPeso).max().orElse(1);
                for (int i = 0; i < n; i++) {
                    int x = margen + i * (ancho - 2 * margen) / n;
                    int barHeight = (int) ((progreso.get(i).getPeso() / maxPeso) * (alto - 2 * margen));
                    g.setColor(Color.BLUE);
                    g.fillRect(x, alto - margen - barHeight, 20, barHeight);
                    g.setColor(Color.BLACK);
                    g.drawString(String.valueOf(progreso.get(i).getPeso()), x, alto - margen - barHeight - 5);
                }
            }
        };
        add(panelGrafico, BorderLayout.CENTER);
    }
}
