import java.util.*;
import java.io.*;
import modelo.Usuario;

// Clase para gestionar usuarios
public class UsuarioManager {
    // Devuelve el siguiente id disponible para usuario
    public int obtenerNuevoId() {
        int maxId = 0;
        for (Usuario u : listaUsuarios) {
            if (u.getId() > maxId) maxId = u.getId();
        }
        return maxId + 1;
    }
    private List<Usuario> listaUsuarios;

    public UsuarioManager() {
        listaUsuarios = new ArrayList<>();
        cargarUsuariosDesdeDerby();
    }

    // Autenticación usando el servidor
    public Usuario iniciarSesion(String correo, String contraseña) {
        persistencia.UsuarioDAO dao = new persistencia.UsuarioDAO();
        Usuario u = dao.loginUsuario(correo, contraseña);
        if (u != null && buscarPorCorreo(correo) == null) listaUsuarios.add(u);
        return u;
    }

    public boolean registrarUsuario(Usuario usuario) {
        if (buscarPorCorreo(usuario.getCorreo()) == null) {
            listaUsuarios.add(usuario);
            guardarUsuarios();
            // Guardar en Derby
            persistencia.UsuarioDAO dao = new persistencia.UsuarioDAO();
            boolean ok = dao.agregarUsuario(usuario);
            return ok;
        }
        return false;
    }

    public Usuario buscarPorCorreo(String correo) {
        // Buscar en Derby
        persistencia.UsuarioDAO dao = new persistencia.UsuarioDAO();
        for (Usuario u : dao.obtenerTodos()) {
            if (u.getCorreo().equals(correo)) {
                return u;
            }
        }
        return null;
    }

    public boolean editarPerfil(Usuario usuario, String nuevoNombre, String nuevoApellido, String nuevoCorreo) {
        usuario.setNombre(nuevoNombre);
        usuario.setApellido(nuevoApellido);
        usuario.setCorreo(nuevoCorreo);
        guardarUsuarios();
        return true;
    }

    public boolean cambiarContraseña(Usuario usuario, String actual, String nueva) {
        if (usuario.getPassword().equals(actual)) {
            usuario.setPassword(nueva);
            guardarUsuarios();
            return true;
        }
        return false;
    }

    public boolean enviarRecuperacion(String correo) {
        Usuario u = buscarPorCorreo(correo);
        if (u != null) {
            String enlace = "http://fidness.com/reset?user=" + correo;
            UtilCorreo.enviarCorreoRecuperacion(correo, enlace);
            return true;
        }
        return false;
    }

    public boolean guardarUsuarios() {
        try {
            FileWriter fw = new FileWriter("usuarios.txt");
            for (Usuario u : listaUsuarios) {
                fw.write(u.getNombre() + "," + u.getApellido() + "," + u.getCorreo() + "," + u.getPassword() + "\n");
            }
            fw.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public boolean cargarUsuariosDesdeDerby() {
        listaUsuarios.clear();
        persistencia.UsuarioDAO dao = new persistencia.UsuarioDAO();
        listaUsuarios.addAll(dao.obtenerTodos());
        return true;
    }
}
