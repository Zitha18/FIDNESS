// Clase para la información general del gimnasio
public class InformacionGimnasio {
    private String nombre;
    private String direccion;
    private String telefono;
    private String horario;
    private String descripcion;

    public InformacionGimnasio(String nombre, String direccion, String telefono, String horario, String descripcion) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.horario = horario;
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getHorario() {
        return horario;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String toString() {
        return nombre + "\n" + direccion + "\nTel: " + telefono + "\nHorario: " + horario + "\n" + descripcion;
    }
}
