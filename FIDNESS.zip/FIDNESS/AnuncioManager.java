import java.util.ArrayList;
import java.util.List;
// Manager para anuncios
public class AnuncioManager {
    private List<Anuncio> anuncios;

    public AnuncioManager() {
        anuncios = new ArrayList<>();
    }

    public void cargarAnuncios() {
        // Simula carga de archivo
        anuncios.clear();
        anuncios.add(new Anuncio("Bienvenida", "¡Bienvenido al gimnasio Fidness!", "2025-08-01"));
        anuncios.add(new Anuncio("Promo", "Descuento en membresías este mes.", "2025-08-10"));
    }

    public void guardarAnuncios() {
        // Simula guardado
    }

    public List<Anuncio> getAnuncios() {
        return anuncios;
    }

    public void agregarAnuncio(Anuncio anuncio) {
        anuncios.add(anuncio);
    }
}
