import java.io.*;

// Utilidad para exportar rutina a PDF (simulado como .txt)
public class ExportarPDFUtil {
    public static boolean exportarRutina(Rutina rutina, String archivo) {
        try {
            FileWriter fw = new FileWriter(archivo);
            fw.write("Rutina: " + rutina.getNombre() + "\n\n");
            int i = 1;
            for (EjercicioEnRutina er : rutina.getEjercicios()) {
                fw.write(i + ". " + er.getEjercicio().getNombre() + " - Nota: " + (er.getNota() != null ? er.getNota() : "") + "\n");
                i++;
            }
            fw.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}
