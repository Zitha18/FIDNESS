// Clase que representa un usuario del gimnasio
public class Usuario {
    private String nombre;
    private String apellido;
    private String correo;
    private String contraseña;
    private boolean recordarme;
    private boolean admin;

    // Constructor normal
    public Usuario(String nombre, String apellido, String correo, String contraseña) {
        this(nombre, apellido, correo, contraseña, false, false);
    }

    // Constructor completo
    public Usuario(String nombre, int edad, String correo, String contraseña, boolean recordarme, boolean admin) {
        this.nombre = nombre;
        this.apellido = "";
        this.correo = correo;
        this.contraseña = contraseña;
        this.recordarme = recordarme;
        this.admin = admin;
    }

    public Usuario(String nombre, String apellido, String correo, String contraseña, boolean recordarme, boolean admin) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.contraseña = contraseña;
        this.recordarme = recordarme;
        this.admin = admin;
    }
    public boolean esAdmin() {
        return admin;
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public String getCorreo() {
        return correo;
    }
    public void setCorreo(String correo) {
        this.correo = correo;
    }
    public String getContraseña() {
        return contraseña;
    }
    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    public boolean isRecordarme() {
        return recordarme;
    }
    public void setRecordarme(boolean recordarme) {
        this.recordarme = recordarme;
    }
    // Para debug
    public String toString() {
        return nombre + " " + apellido + " (" + correo + ")";
    }
}
