import modelo.Usuario;
import javax.swing.*;
import java.awt.*;
import java.util.List;

// Panel para mostrar anuncios
public class PanelAnuncios extends JPanel {
    public PanelAnuncios(AnuncioManager anuncioManager, Usuario usuario) {
        setLayout(new BorderLayout());
        JLabel lblTitulo = new JLabel("Anuncios del Gimnasio");
        add(lblTitulo, BorderLayout.NORTH);

        DefaultListModel<String> modelo = new DefaultListModel<>();
        List<Anuncio> anuncios = anuncioManager.getAnuncios();
        for (Anuncio a : anuncios) {
            modelo.addElement(a.toString());
        }
        JList<String> lista = new JList<>(modelo);
        JScrollPane scroll = new JScrollPane(lista);
        add(scroll, BorderLayout.CENTER);

    if (usuario != null && usuario.isAdmin()) {
            JButton btnAgregar = new JButton("Agregar anuncio");
            btnAgregar.addActionListener(e -> {
                String titulo = JOptionPane.showInputDialog(this, "Título del anuncio:");
                String contenido = JOptionPane.showInputDialog(this, "Contenido del anuncio:");
                if (titulo != null && contenido != null && !titulo.trim().isEmpty() && !contenido.trim().isEmpty()) {
                    anuncioManager.agregarAnuncio(new Anuncio(titulo.trim(), contenido.trim(), "2025-08-25"));
                    modelo.addElement(anuncioManager.getAnuncios().get(modelo.size()).toString());
                }
            });
            add(btnAgregar, BorderLayout.SOUTH);
        }
    }
}
