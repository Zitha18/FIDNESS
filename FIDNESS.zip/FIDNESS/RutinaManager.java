import java.util.*;
import java.io.*;

// Gestión de rutinas
public class RutinaManager {
    private List<Rutina> listaRutinas;

    public RutinaManager() {
        listaRutinas = new ArrayList<>();
        cargarRutinas();
    }
    public Rutina crearRutina(String nombre) {
        Rutina r = new Rutina(nombre);
        listaRutinas.add(r);
        guardarRutinas();
        return r;
    }
    public void eliminarRutina(int index) {
        if (index >= 0 && index < listaRutinas.size()) {
            listaRutinas.remove(index);
            guardarRutinas();
        }
    }
    public Rutina duplicarRutina(Rutina original) {
        Rutina copia = original.duplicar();
        listaRutinas.add(copia);
        guardarRutinas();
        return copia;
    }
    public List<Rutina> getListaRutinas() {
        return listaRutinas;
    }
    public boolean guardarRutinas() {
        try {
            FileWriter fw = new FileWriter("rutinas.txt");
            for (Rutina r : listaRutinas) {
                fw.write(r.getNombre() + ";");
                for (EjercicioEnRutina er : r.getEjercicios()) {
                    fw.write(er.getEjercicio().getNombre() + "|" + (er.getNota() != null ? er.getNota() : "") + ",");
                }
                fw.write("\n");
            }
            fw.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }
    public boolean cargarRutinas() {
        listaRutinas.clear();
        try {
            File f = new File("rutinas.txt");
            if (!f.exists()) return false;
            Scanner sc = new Scanner(f);
            while (sc.hasNextLine()) {
                String linea = sc.nextLine();
                String[] partes = linea.split(";");
                if (partes.length >= 1) {
                    Rutina r = new Rutina(partes[0]);
                    if (partes.length > 1) {
                        String[] ejercicios = partes[1].split(",");
                        for (String ej : ejercicios) {
                            if (!ej.trim().isEmpty()) {
                                String[] datos = ej.split("\\|");
                                Ejercicio ejercicio = new Ejercicio(datos[0], new ArrayList<>(), new ArrayList<>(), "");
                                String nota = datos.length > 1 ? datos[1] : "";
                                r.agregarEjercicio(ejercicio, nota);
                            }
                        }
                    }
                    listaRutinas.add(r);
                }
            }
            sc.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}
