package modelo;
import java.io.Serializable;
import java.sql.Date;

public class Historial implements Serializable {
    private int id;
    private int usuarioId;
    private int ejercicioId;
    private Date fecha;
    private int repeticiones;

    public Historial(int id, int usuarioId, int ejercicioId, Date fecha, int repeticiones) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.ejercicioId = ejercicioId;
        this.fecha = fecha;
        this.repeticiones = repeticiones;
    }
    public int getId() { return id; }
    public int getUsuarioId() { return usuarioId; }
    public int getEjercicioId() { return ejercicioId; }
    public Date getFecha() { return fecha; }
    public int getRepeticiones() { return repeticiones; }
    public void setId(int id) { this.id = id; }
    public void setUsuarioId(int usuarioId) { this.usuarioId = usuarioId; }
    public void setEjercicioId(int ejercicioId) { this.ejercicioId = ejercicioId; }
    public void setFecha(Date fecha) { this.fecha = fecha; }
    public void setRepeticiones(int repeticiones) { this.repeticiones = repeticiones; }
}
