package modelo;
import java.io.Serializable;

public class Usuario implements Serializable {
    private int id;
    private String nombre;
    private String apellido;
    private String correo;
    private String password;
    private boolean admin;
    private boolean recordarme;

    public Usuario(int id, String nombre, String apellido, String correo, String password, boolean admin, boolean recordarme) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.password = password;
        this.admin = admin;
        this.recordarme = recordarme;
    }
    // Constructor simple para compatibilidad
    public Usuario(int id, String nombre, String correo, String password, boolean admin) {
        this(id, nombre, "", correo, password, admin, false);
    }
    // Getters
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getApellido() { return apellido; }
    public String getCorreo() { return correo; }
    public String getPassword() { return password; }
    public boolean isAdmin() { return admin; }
    public boolean isRecordarme() { return recordarme; }
    // Setters
    public void setId(int id) { this.id = id; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setApellido(String apellido) { this.apellido = apellido; }
    public void setCorreo(String correo) { this.correo = correo; }
    public void setPassword(String password) { this.password = password; }
    public void setAdmin(boolean admin) { this.admin = admin; }
    public void setRecordarme(boolean recordarme) { this.recordarme = recordarme; }
}
