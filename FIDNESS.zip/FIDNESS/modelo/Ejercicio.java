package modelo;
// Modelo básico de Ejercicio
import java.io.Serializable;

public class Ejercicio implements Serializable {
    private int id;
    private String nombre;
    private String categoria;
    private boolean activo;

    public Ejercicio(int id, String nombre, String categoria, boolean activo) {
        this.id = id;
        this.nombre = nombre;
        this.categoria = categoria;
        this.activo = activo;
    }
        // Getters
        public int getId() {
            return id;
        }
        public String getNombre() {
            return nombre;
        }
        public String getCategoria() {
            return categoria;
        }
        public boolean isActivo() {
            return activo;
        }
        // Setters (opcional)
        public void setId(int id) {
            this.id = id;
        }
        public void setNombre(String nombre) {
            this.nombre = nombre;
        }
        public void setCategoria(String categoria) {
            this.categoria = categoria;
        }
        public void setActivo(boolean activo) {
            this.activo = activo;
        }
}
